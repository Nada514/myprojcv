# TalentLink — Intelligent Recruitment Support System (MVP)

A university prototype demonstrating how AI can support recruiters: upload resumes and job
descriptions, extract structured candidate data, score and rank candidates against a job with
semantic AI matching, and always explain the score. **The AI never makes hiring decisions — it
only assists. The recruiter always decides.**

## Stack

- **Frontend:** React + Vite + Tailwind CSS (`client/`)
- **Backend:** Node.js + Express (`server/`)
- **Database:** SQLite (via Node's built-in `node:sqlite`, no native build step required)
- **AI:** Claude API (`@anthropic-ai/sdk`), behind a swappable provider interface
- **File storage:** local disk (`server/uploads/`)

## Project structure

```
client/   React app (pages, components, API wrappers)
server/   Express API (routes, controllers, services, SQLite schema/migrations)
```

See `server/src/services/ai/` for the AI provider abstraction — resume extraction
(`extractResume.js`) and job matching (`matchCandidate.js`) both go through
`aiProvider.js`, so adding a new provider (e.g. OpenAI) means adding one file, not touching
any routes or controllers.

## Setup

### 1. Backend

```bash
cd server
npm install
cp .env.example .env
```

Edit `server/.env` and set `ANTHROPIC_API_KEY` to a real Anthropic API key (resume extraction
and candidate matching won't work without it — everything else in the app functions normally).

```bash
npm run migrate   # creates the SQLite DB and seeds the demo recruiter + admin accounts
npm run dev        # starts the API on http://localhost:4000
```

The seeded logins (also configurable in `.env`):

- **Recruiter** — Email: `recruiter@talentlink.dev` / Password: `recruiter123`
- **Admin** (manages the criteria library) — Email: `admin@talentlink.dev` / Password: `admin123`

### 2. Frontend

```bash
cd client
npm install
npm run dev   # starts the app on http://localhost:5173
```

The Vite dev server proxies `/api` requests to `http://localhost:4000`, so run both servers
together during development.

## How AI matching works

1. **Extraction** — when a resume is uploaded, its text (from PDF/DOCX) is sent to Claude with
   a strict instruction: only extract what's explicitly present, never invent data, and list any
   expected fields it couldn't find (`missing_fields`).
2. **Matching** — when a recruiter runs matching on a job, each candidate's structured profile
   and the job's requirements are sent to Claude, which returns an overall score plus separate
   skills/experience/education scores, concrete strengths, concrete gaps, and a plain-language
   explanation. Matching is semantic (e.g. "React" satisfies a "Frontend Development"
   requirement), not just keyword matching.
3. Hard requirements (age range, minimum years of experience) are checked deterministically in
   code, not left to the model, and folded into the same "missing requirements" list.
4. Every score is always stored and displayed together with its explanation — the UI has no code
   path that shows a score without a reason.

## Future expansion

The codebase is intentionally structured so these can be added without restructuring:

- Additional AI providers (OpenAI, etc.) — add a file in `server/src/services/ai/`
- Google Drive / calendar integration — add a service + route
- Multiple recruiter accounts — `users` table and auth already support it; only signup/invite UI
  is missing
- Email notifications, AI interview question generation, analytics dashboard, mobile app — each
  is additive: a new service, route, and (where relevant) page
