import { Briefcase, BookOpen, Users, GitCompareArrows, Settings as SettingsIcon } from 'lucide-react'

export const navItems = [
  { to: '/jobs', label: 'Jobs', icon: Briefcase, end: true },
  { to: '/criteria', label: 'Criteria Library', icon: BookOpen },
  { to: '/candidates', label: 'Candidates', icon: Users },
  { to: '/compare', label: 'Compare', icon: GitCompareArrows },
  { to: '/settings', label: 'Settings', icon: SettingsIcon },
]
