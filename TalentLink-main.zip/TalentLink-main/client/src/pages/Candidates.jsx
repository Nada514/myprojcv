import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Search, Upload, GitCompareArrows, Users } from 'lucide-react'
import { fetchCandidates, deleteCandidate } from '../api/candidatesApi'
import { getErrorMessage } from '../api/getErrorMessage'
import { useToast } from '../hooks/useToast'
import { useAuth } from '../hooks/useAuth'
import Loading from '../components/Loading'
import ErrorBanner from '../components/ErrorBanner'
import EmptyState from '../components/EmptyState'
import CandidateCard from '../components/CandidateCard'
import FilterSidebar from '../components/FilterSidebar'
import ResumeUploadModal from '../components/ResumeUploadModal'
import ConfirmDialog from '../components/ConfirmDialog'
import Button from '../components/Button'
import PageHeader from '../components/PageHeader'

const emptyFilters = {
  age_min: '',
  age_max: '',
  experience_min: '',
  education: '',
  skill: '',
  language: '',
  certification: '',
  score_min: '',
}

export default function Candidates() {
  const navigate = useNavigate()
  const { showToast } = useToast()
  const { user } = useAuth()
  const [searchParams, setSearchParams] = useSearchParams()
  const [candidates, setCandidates] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [filters, setFilters] = useState(emptyFilters)
  const [search, setSearch] = useState('')
  const [sortByScore, setSortByScore] = useState(user?.preferences?.defaultSortByScore ?? true)
  const [showUpload, setShowUpload] = useState(false)
  const [selectedIds, setSelectedIds] = useState([])
  const [deletingCandidate, setDeletingCandidate] = useState(null)

  async function loadCandidates() {
    setLoading(true)
    setError('')
    try {
      const params = { ...filters, sort: sortByScore ? 'score' : undefined }
      setCandidates(await fetchCandidates(params))
    } catch (err) {
      setError(getErrorMessage(err, 'Could not load candidates'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadCandidates()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters, sortByScore])

  useEffect(() => {
    if (searchParams.get('upload') === '1') {
      setShowUpload(true)
      const next = new URLSearchParams(searchParams)
      next.delete('upload')
      setSearchParams(next, { replace: true })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const visibleCandidates = useMemo(() => {
    if (!search.trim()) return candidates
    const needle = search.toLowerCase()
    return candidates.filter(
      (c) => (c.name || '').toLowerCase().includes(needle) || (c.email || '').toLowerCase().includes(needle),
    )
  }, [candidates, search])

  function toggleSelected(id) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
  }

  async function handleDelete() {
    await deleteCandidate(deletingCandidate.id)
    setCandidates((prev) => prev.filter((c) => c.id !== deletingCandidate.id))
    setSelectedIds((prev) => prev.filter((id) => id !== deletingCandidate.id))
    showToast(`${deletingCandidate.name || 'Candidate'} was deleted`)
    setDeletingCandidate(null)
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Candidates"
        description="Browse, filter, and compare extracted candidate profiles."
        actions={
          <>
            {selectedIds.length >= 2 && (
              <Button
                variant="secondary"
                icon={GitCompareArrows}
                onClick={() => navigate(`/compare?ids=${selectedIds.join(',')}`)}
              >
                Compare ({selectedIds.length})
              </Button>
            )}
            <Button icon={Upload} onClick={() => setShowUpload(true)}>
              Upload Resumes
            </Button>
          </>
        }
      />

      <div className="flex flex-col gap-6 lg:flex-row">
        <FilterSidebar
          filters={filters}
          onChange={(key, value) => setFilters((prev) => ({ ...prev, [key]: value }))}
          onClear={() => setFilters(emptyFilters)}
        />

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative max-w-sm flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name or email..."
                className="focus-ring w-full rounded-lg border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-brand-500"
              />
            </div>
            <label className="flex items-center gap-2 text-sm text-slate-600">
              <input
                type="checkbox"
                checked={sortByScore}
                onChange={(e) => setSortByScore(e.target.checked)}
                className="rounded border-slate-300 text-brand-600 focus:ring-brand-500"
              />
              Sort by match score
            </label>
          </div>

          <div className="mt-4">
            {loading && <Loading variant="cards" count={4} />}
            {!loading && error && <ErrorBanner message={error} onRetry={loadCandidates} />}

            {!loading && !error && visibleCandidates.length === 0 && (
              <EmptyState
                icon={Users}
                title="No candidates found"
                description="Upload resumes to start building your candidate pool, or adjust your filters."
                action={
                  <Button icon={Upload} onClick={() => setShowUpload(true)}>
                    Upload Resumes
                  </Button>
                }
              />
            )}

            {!loading && !error && visibleCandidates.length > 0 && (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
                {visibleCandidates.map((c) => (
                  <CandidateCard
                    key={c.id}
                    candidate={c}
                    selected={selectedIds.includes(c.id)}
                    onToggleSelect={() => toggleSelected(c.id)}
                    onDelete={() => setDeletingCandidate(c)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {showUpload && (
        <ResumeUploadModal
          onClose={() => setShowUpload(false)}
          onUploaded={(uploaded) => {
            loadCandidates()
            const succeeded = uploaded.filter((r) => r.candidate_id).length
            const failed = uploaded.length - succeeded
            if (failed === 0) {
              showToast(`${succeeded} candidate${succeeded === 1 ? '' : 's'} extracted successfully`)
            } else if (succeeded > 0) {
              showToast(`${succeeded} extracted, ${failed} failed - see upload details`, 'error')
            } else {
              showToast(`AI extraction failed for ${failed} resume${failed === 1 ? '' : 's'} - see upload details`, 'error')
            }
          }}
        />
      )}
      {deletingCandidate && (
        <ConfirmDialog
          title="Delete candidate"
          message={`Delete ${deletingCandidate.name || 'this candidate'}? This will also remove their match evaluations.`}
          confirmLabel="Delete"
          onConfirm={handleDelete}
          onCancel={() => setDeletingCandidate(null)}
        />
      )}
    </div>
  )
}
