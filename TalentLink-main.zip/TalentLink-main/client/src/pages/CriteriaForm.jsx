import { useEffect, useState } from 'react'
import { useParams, useNavigate, Navigate, Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { fetchCriteria, createCriteria, updateCriteria } from '../api/criteriaApi'
import { getErrorMessage } from '../api/getErrorMessage'
import { useAuth } from '../hooks/useAuth'
import { useToast } from '../hooks/useToast'
import Loading from '../components/Loading'
import ErrorBanner from '../components/ErrorBanner'
import Card from '../components/Card'
import Input from '../components/Input'
import TagInput from '../components/TagInput'
import Button from '../components/Button'
import PageHeader from '../components/PageHeader'

const emptyCriteria = {
  department: '',
  role_title: '',
  description: '',
  education_requirements: [],
  minimum_experience_years: '',
  certifications: [],
  min_age: '',
  max_age: '',
  required_skills: [],
  preferred_skills: [],
  competencies: [],
  portfolio_requirements: [],
  evaluation_rules: {
    technical_skills: { weight: 45, method: '' },
    experience: { weight: 25, method: '' },
    education: { weight: 15, method: '' },
    portfolio: { weight: 10, method: '' },
    competencies: { weight: 5, method: '' },
  },
}

const CATEGORY_FIELDS = [
  { key: 'technical_skills', label: 'Technical Skills' },
  { key: 'experience', label: 'Experience' },
  { key: 'education', label: 'Education' },
  { key: 'portfolio', label: 'Projects / Portfolio' },
  { key: 'competencies', label: 'Professional Competencies' },
]

const fieldClass =
  'focus-ring mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500'

function toNumberOrNull(value) {
  if (value === '' || value === null || value === undefined) return null
  return Number(value)
}

export default function CriteriaForm() {
  const { id } = useParams()
  const isEdit = Boolean(id)
  const navigate = useNavigate()
  const { user } = useAuth()
  const { showToast } = useToast()

  const [form, setForm] = useState(emptyCriteria)
  const [loading, setLoading] = useState(isEdit)
  const [loadError, setLoadError] = useState('')
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!isEdit) return
    setLoading(true)
    fetchCriteria(id)
      .then((data) =>
        setForm({
          ...emptyCriteria,
          ...data,
          evaluation_rules: { ...emptyCriteria.evaluation_rules, ...data.evaluation_rules },
        }),
      )
      .catch((err) => setLoadError(getErrorMessage(err, 'Could not load this criteria template')))
      .finally(() => setLoading(false))
  }, [id, isEdit])

  if (user && user.role !== 'admin') {
    return <Navigate to="/criteria" replace />
  }

  function update(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  function updateRule(key, field, value) {
    setForm((prev) => ({
      ...prev,
      evaluation_rules: {
        ...prev.evaluation_rules,
        [key]: { ...prev.evaluation_rules[key], [field]: field === 'weight' ? (value === '' ? 0 : Number(value)) : value },
      },
    }))
  }

  const weightSum = CATEGORY_FIELDS.reduce(
    (total, { key }) => total + (Number(form.evaluation_rules[key]?.weight) || 0),
    0,
  )
  const missingMethod = CATEGORY_FIELDS.find(({ key }) => !form.evaluation_rules[key]?.method?.trim())

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    if (!form.department?.trim()) {
      setError('Department is required')
      return
    }
    if (!form.role_title?.trim()) {
      setError('Role title is required')
      return
    }
    if (form.required_skills.length === 0) {
      setError('Add at least one required skill')
      return
    }
    if (weightSum !== 100) {
      setError(`Evaluation weights must add up to 100% (currently ${weightSum}%)`)
      return
    }
    if (missingMethod) {
      setError(`Explain how "${missingMethod.label}" is evaluated`)
      return
    }
    setSubmitting(true)
    try {
      const payload = {
        ...form,
        minimum_experience_years: toNumberOrNull(form.minimum_experience_years),
        min_age: toNumberOrNull(form.min_age),
        max_age: toNumberOrNull(form.max_age),
      }
      const saved = isEdit ? await updateCriteria(id, payload) : await createCriteria(payload)
      showToast(`"${saved.role_title}" template was saved`)
      navigate(`/criteria/${saved.id}`)
    } catch (err) {
      setError(getErrorMessage(err, 'Could not save this criteria template'))
      setSubmitting(false)
    }
  }

  if (loading) return <Loading variant="cards" count={4} />
  if (loadError) return <ErrorBanner message={loadError} />

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link
          to="/criteria"
          className="focus-ring inline-flex items-center gap-1 rounded text-xs font-medium text-brand-600 hover:underline"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to criteria library
        </Link>
      </div>

      <PageHeader
        title={isEdit ? 'Edit Criteria Template' : 'New Criteria Template'}
        description="Define the department's objective professional competency standard for this role, used across every job posting that attaches it."
      />

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        {error && <ErrorBanner message={error} />}

        <Card title="Basic Information">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input
              id="criteria-department"
              label="Department"
              required
              value={form.department}
              onChange={(e) => update('department', e.target.value)}
              placeholder="e.g. Computer Science"
            />
            <Input
              id="criteria-role"
              label="Role"
              required
              value={form.role_title}
              onChange={(e) => update('role_title', e.target.value)}
              placeholder="e.g. Software Engineer"
            />
          </div>
          <div className="mt-4">
            <label className="text-sm font-medium text-slate-700">Description</label>
            <textarea
              value={form.description || ''}
              onChange={(e) => update('description', e.target.value)}
              className={fieldClass}
              rows={3}
              placeholder="What this role standard covers and why it matters"
            />
          </div>
        </Card>

        <Card title="Qualifications" description="Education, experience, certifications, and age requirements">
          <div className="flex flex-col gap-4">
            <TagInput
              label="Education requirements"
              values={form.education_requirements}
              onChange={(v) => update('education_requirements', v)}
              placeholder="e.g. Bachelor's in Computer Science"
            />
            <Input
              id="criteria-min-experience"
              type="number"
              min="0"
              step="0.5"
              label="Minimum years of experience"
              className="max-w-xs"
              value={form.minimum_experience_years ?? ''}
              onChange={(e) => update('minimum_experience_years', e.target.value)}
            />
            <TagInput
              label="Certifications (optional)"
              values={form.certifications}
              onChange={(v) => update('certifications', v)}
              placeholder="e.g. AWS Certified Developer"
            />
            <div className="grid grid-cols-2 gap-4 max-w-md">
              <Input
                id="criteria-min-age"
                type="number"
                min="0"
                label="Min. age (optional)"
                value={form.min_age ?? ''}
                onChange={(e) => update('min_age', e.target.value)}
              />
              <Input
                id="criteria-max-age"
                type="number"
                min="0"
                label="Max. age (optional)"
                value={form.max_age ?? ''}
                onChange={(e) => update('max_age', e.target.value)}
              />
            </div>
          </div>
        </Card>

        <Card title="Technical Skills">
          <div className="flex flex-col gap-4">
            <TagInput
              label="Required skills"
              required
              values={form.required_skills}
              onChange={(v) => update('required_skills', v)}
              placeholder="Type a skill and press Enter"
            />
            <TagInput
              label="Preferred skills"
              values={form.preferred_skills}
              onChange={(v) => update('preferred_skills', v)}
              placeholder="Type a skill and press Enter"
            />
          </div>
        </Card>

        <Card
          title="Professional Competencies"
          description="Soft skills the AI should look for evidence of, e.g. Communication, Teamwork, Leadership"
        >
          <TagInput
            values={form.competencies}
            onChange={(v) => update('competencies', v)}
            placeholder="e.g. Problem solving, Adaptability"
          />
        </Card>

        <Card title="Portfolio Requirements" description="Optional - what projects/portfolio work should demonstrate">
          <TagInput
            values={form.portfolio_requirements}
            onChange={(v) => update('portfolio_requirements', v)}
            placeholder="e.g. A deployed full-stack project"
          />
        </Card>

        <Card
          title="Evaluation Rules"
          description="Each category's weight (must total 100%) plus how the AI should evaluate it - not just a percentage"
        >
          <div className="flex flex-col gap-5">
            {CATEGORY_FIELDS.map(({ key, label }) => (
              <div key={key} className="rounded-lg border border-slate-200 p-3">
                <div className="flex items-center gap-3">
                  <span className="flex-1 text-sm font-medium text-slate-700">{label}</span>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={form.evaluation_rules[key]?.weight ?? 0}
                    onChange={(e) => updateRule(key, 'weight', e.target.value)}
                    className="w-20 rounded-lg border border-slate-300 px-2 py-1.5 text-sm focus-ring focus:border-brand-500"
                  />
                  <span className="text-sm text-slate-400">%</span>
                </div>
                <textarea
                  value={form.evaluation_rules[key]?.method ?? ''}
                  onChange={(e) => updateRule(key, 'method', e.target.value)}
                  className={`${fieldClass} mt-2`}
                  rows={2}
                  placeholder={`How should the AI evaluate ${label.toLowerCase()}?`}
                />
              </div>
            ))}
            <p className={`text-sm font-medium ${weightSum === 100 ? 'text-emerald-600' : 'text-amber-600'}`}>
              Total: {weightSum}% {weightSum !== 100 && '(must equal 100%)'}
            </p>
          </div>
        </Card>

        <div className="mt-2 flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={() => navigate('/criteria')}>
            Cancel
          </Button>
          <Button type="submit" disabled={submitting || weightSum !== 100}>
            {submitting ? 'Saving...' : isEdit ? 'Save changes' : 'Create template'}
          </Button>
        </div>
      </form>
    </div>
  )
}
