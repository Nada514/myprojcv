import { useAuth } from '../hooks/useAuth'
import PageHeader from '../components/PageHeader'
import ProfileCard from '../components/ProfileCard'
import AccountInfoCard from '../components/AccountInfoCard'
import PasswordChangeForm from '../components/PasswordChangeForm'
import PreferencesCard from '../components/PreferencesCard'
import DangerZoneCard from '../components/DangerZoneCard'

export default function Settings() {
  const { user } = useAuth()

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Settings" description="Manage your recruiter account." />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="flex flex-col gap-6 lg:col-span-2">
          <ProfileCard />
          <PasswordChangeForm />
          <DangerZoneCard />
        </div>
        <div className="flex flex-col gap-6">
          <AccountInfoCard user={user} />
          <PreferencesCard />
        </div>
      </div>
    </div>
  )
}
