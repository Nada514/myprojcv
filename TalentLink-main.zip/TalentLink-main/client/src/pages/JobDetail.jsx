import { useEffect, useMemo, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Sparkles, ArrowLeft, ArrowUpDown, GraduationCap, MapPin, Briefcase, DollarSign } from 'lucide-react'
import { fetchJob, updateJob } from '../api/jobsApi'
import { runMatch, fetchJobEvaluations } from '../api/evaluationsApi'
import { getErrorMessage } from '../api/getErrorMessage'
import { useToast } from '../hooks/useToast'
import Loading from '../components/Loading'
import ErrorBanner from '../components/ErrorBanner'
import EmptyState from '../components/EmptyState'
import ScoreBadge from '../components/ScoreBadge'
import StatusBadge from '../components/StatusBadge'
import JobFormModal from '../components/JobFormModal'
import Button from '../components/Button'
import AICard from '../components/AICard'

const columns = [
  { key: 'candidate_name', label: 'Candidate' },
  { key: 'overall_score', label: 'Overall' },
  { key: 'department_score', label: 'Department Match' },
  { key: 'company_score', label: 'Company Match' },
]

function formatSalary(job) {
  if (job.salary_min == null && job.salary_max == null) return null
  if (job.salary_min != null && job.salary_max != null) return `${job.salary_min} - ${job.salary_max}`
  return job.salary_min ?? job.salary_max
}

export default function JobDetail() {
  const { jobId } = useParams()
  const { showToast } = useToast()
  const [job, setJob] = useState(null)
  const [evaluations, setEvaluations] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [matching, setMatching] = useState(false)
  const [matchError, setMatchError] = useState('')
  const [showEdit, setShowEdit] = useState(false)
  const [sort, setSort] = useState({ key: 'overall_score', dir: 'desc' })

  async function loadAll() {
    setLoading(true)
    setError('')
    try {
      const [jobData, evalData] = await Promise.all([fetchJob(jobId), fetchJobEvaluations(jobId)])
      setJob(jobData)
      setEvaluations(evalData)
    } catch (err) {
      setError(getErrorMessage(err, 'Could not load job'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadAll()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobId])

  async function handleRunMatch() {
    setMatching(true)
    setMatchError('')
    try {
      const result = await runMatch(jobId)
      if (result.errors?.length) {
        setMatchError(
          `${result.errors.length} candidate(s) could not be evaluated (${result.errors[0].message}).`,
        )
      } else {
        showToast(`Matching complete for ${result.evaluations.length} candidate(s)`)
      }
      const evalData = await fetchJobEvaluations(jobId)
      setEvaluations(evalData)
    } catch (err) {
      setMatchError(getErrorMessage(err, 'Matching failed'))
    } finally {
      setMatching(false)
    }
  }

  function toggleSort(key) {
    setSort((prev) => (prev.key === key ? { key, dir: prev.dir === 'desc' ? 'asc' : 'desc' } : { key, dir: 'desc' }))
  }

  const sortedEvaluations = useMemo(() => {
    const rows = [...evaluations]
    rows.sort((a, b) => {
      const av = a[sort.key]
      const bv = b[sort.key]
      if (av == null) return 1
      if (bv == null) return -1
      if (typeof av === 'string') return sort.dir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av)
      return sort.dir === 'asc' ? av - bv : bv - av
    })
    return rows
  }, [evaluations, sort])

  if (loading) {
    return (
      <div className="flex flex-col gap-6">
        <Loading variant="stats" count={1} />
        <Loading variant="table" count={4} />
      </div>
    )
  }
  if (error) return <ErrorBanner message={error} onRetry={loadAll} />
  if (!job) return null

  const salary = formatSalary(job)

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link to="/jobs" className="focus-ring inline-flex items-center gap-1 rounded text-xs font-medium text-brand-600 hover:underline">
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to jobs
        </Link>
        <div className="mt-1 flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold tracking-tight text-navy-900">{job.title}</h1>
              <StatusBadge status={job.status} />
            </div>
            <p className="mt-1 text-sm text-slate-500">{job.department || 'No department'}</p>
            {job.criteria_template_id ? (
              <Link
                to={`/criteria/${job.criteria_template_id}`}
                className="focus-ring mt-2 inline-flex items-center gap-1 rounded-full bg-brand-50 px-2.5 py-1 text-xs font-medium text-brand-700 hover:bg-brand-100"
              >
                <GraduationCap className="h-3.5 w-3.5" />
                {job.criteria_department} → {job.criteria_role_title}
              </Link>
            ) : (
              <p className="mt-2 text-xs text-amber-600">
                No criteria template linked - edit this job to attach one before running AI matching.
              </p>
            )}
          </div>
          <Button variant="secondary" size="sm" onClick={() => setShowEdit(true)}>
            Edit job
          </Button>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap gap-4 text-sm text-slate-500">
          {job.employment_type && (
            <span className="flex items-center gap-1">
              <Briefcase className="h-3.5 w-3.5" /> {job.employment_type}
            </span>
          )}
          {job.location && (
            <span className="flex items-center gap-1">
              <MapPin className="h-3.5 w-3.5" /> {job.location}
            </span>
          )}
          {salary && (
            <span className="flex items-center gap-1">
              <DollarSign className="h-3.5 w-3.5" /> {salary}
            </span>
          )}
        </div>

        <div className="mt-4">
          <p className="text-xs font-medium uppercase text-slate-400">About the role</p>
          <p className="mt-1 text-sm text-slate-700">{job.about_role || 'No description provided.'}</p>
        </div>

        {job.responsibilities && (
          <div className="mt-4">
            <p className="text-xs font-medium uppercase text-slate-400">Responsibilities</p>
            <p className="mt-1 whitespace-pre-line text-sm text-slate-700">{job.responsibilities}</p>
          </div>
        )}

        {job.company_info && (
          <div className="mt-4">
            <p className="text-xs font-medium uppercase text-slate-400">Company</p>
            <p className="mt-1 text-sm text-slate-700">{job.company_info}</p>
          </div>
        )}

        {job.team_info && (
          <div className="mt-4">
            <p className="text-xs font-medium uppercase text-slate-400">Team</p>
            <p className="mt-1 text-sm text-slate-700">{job.team_info}</p>
          </div>
        )}

        {job.benefits && (
          <div className="mt-4">
            <p className="text-xs font-medium uppercase text-slate-400">Benefits</p>
            <p className="mt-1 text-sm text-slate-700">{job.benefits}</p>
          </div>
        )}
      </div>

      <AICard
        title="AI Match Results"
        action={
          <Button icon={Sparkles} variant="ai" size="sm" onClick={handleRunMatch} disabled={matching}>
            {matching ? 'Running...' : 'Run AI Matching'}
          </Button>
        }
      >
        {matchError && (
          <div className="mb-4">
            <ErrorBanner message={matchError} onRetry={handleRunMatch} />
          </div>
        )}

        {evaluations.length === 0 ? (
          <EmptyState
            icon={Sparkles}
            title="No matches yet"
            description="Run AI matching to score all candidates against the department standard and this job's own posting."
          />
        ) : (
          <div className="overflow-x-auto rounded-xl border border-slate-200">
            <table className="w-full min-w-[560px] text-left text-sm">
              <thead className="sticky top-0 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  {columns.map((col) => (
                    <th key={col.key} className="px-4 py-3">
                      <button
                        onClick={() => toggleSort(col.key)}
                        className="focus-ring flex items-center gap-1 rounded hover:text-slate-700"
                      >
                        {col.label}
                        <ArrowUpDown className="h-3 w-3" />
                      </button>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {sortedEvaluations.map((evaluation) => (
                  <tr key={evaluation.id} className="transition-colors hover:bg-slate-50">
                    <td className="px-4 py-3">
                      <Link
                        to={`/candidates/${evaluation.candidate_id}`}
                        className="focus-ring rounded font-medium text-navy-900 hover:text-brand-600"
                      >
                        {evaluation.candidate_name || 'Unnamed candidate'}
                      </Link>
                      <p className="text-xs text-slate-500">{evaluation.candidate_email}</p>
                    </td>
                    <td className="px-4 py-3">
                      <ScoreBadge score={evaluation.overall_score} />
                    </td>
                    <td className="px-4 py-3 text-slate-600">
                      {evaluation.department_score != null ? `${Math.round(evaluation.department_score)}%` : '—'}
                    </td>
                    <td className="px-4 py-3 text-slate-600">
                      {evaluation.company_score != null ? `${Math.round(evaluation.company_score)}%` : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </AICard>

      {showEdit && (
        <JobFormModal
          job={job}
          onClose={() => setShowEdit(false)}
          onSubmit={async (updated) => {
            const saved = await updateJob(job.id, updated)
            setJob(saved)
            setShowEdit(false)
            showToast(`"${saved.title}" was updated`)
          }}
        />
      )}
    </div>
  )
}
