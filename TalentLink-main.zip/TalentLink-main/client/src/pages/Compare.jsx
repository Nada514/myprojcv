import { useEffect, useState } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { ArrowLeft, GitCompareArrows, Users } from 'lucide-react'
import { compareCandidates } from '../api/compareApi'
import { getErrorMessage } from '../api/getErrorMessage'
import Loading from '../components/Loading'
import ErrorBanner from '../components/ErrorBanner'
import EmptyState from '../components/EmptyState'
import ScoreBadge from '../components/ScoreBadge'
import Button from '../components/Button'
import Avatar from '../components/Avatar'

function Cell({ children }) {
  return <td className="align-top px-4 py-3 text-sm text-slate-700">{children}</td>
}

function TagList({ items, emptyLabel = '—', tone = 'default' }) {
  if (!items || items.length === 0) return <span className="text-slate-400">{emptyLabel}</span>
  const toneClass =
    tone === 'positive'
      ? 'bg-emerald-50 text-emerald-700'
      : tone === 'negative'
        ? 'bg-amber-50 text-amber-700'
        : 'bg-slate-100 text-slate-600'
  return (
    <div className="flex flex-wrap gap-1">
      {items.map((item) => (
        <span key={item} className={`rounded-full px-2 py-0.5 text-xs font-medium ${toneClass}`}>
          {item}
        </span>
      ))}
    </div>
  )
}

export default function Compare() {
  const [searchParams] = useSearchParams()
  const ids = searchParams.get('ids')
  const [candidates, setCandidates] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!ids) {
      setLoading(false)
      return
    }
    const candidateIds = ids.split(',').map(Number).filter(Boolean)
    setLoading(true)
    setError('')
    compareCandidates(candidateIds)
      .then((data) => setCandidates(data.candidates))
      .catch((err) => setError(getErrorMessage(err, 'Could not load comparison')))
      .finally(() => setLoading(false))
  }, [ids])

  if (!ids) {
    return (
      <EmptyState
        icon={GitCompareArrows}
        title="No candidates selected"
        description="Select two or more candidates from the Candidates page to compare them side by side."
        action={
          <Link to="/candidates">
            <Button icon={Users}>Go to Candidates</Button>
          </Link>
        }
      />
    )
  }

  if (loading) return <Loading variant="table" count={5} />
  if (error) return <ErrorBanner message={error} />

  const rows = [
    { label: 'Overall Match', render: (c) => <ScoreBadge score={c.evaluation?.overall_score} /> },
    {
      label: 'Department Match',
      render: (c) => (c.evaluation?.department_score != null ? `${Math.round(c.evaluation.department_score)}%` : '—'),
    },
    {
      label: 'Company Match',
      render: (c) => (c.evaluation?.company_score != null ? `${Math.round(c.evaluation.company_score)}%` : '—'),
    },
    { label: 'Skills', render: (c) => <TagList items={c.skills} /> },
    { label: 'Programming Languages', render: (c) => <TagList items={c.programming_languages} /> },
    {
      label: 'Experience',
      render: (c) => (c.total_experience_years != null ? `${c.total_experience_years} years` : '—'),
    },
    {
      label: 'Education',
      render: (c) =>
        c.education.length === 0
          ? '—'
          : c.education.map((e) => `${e.degree} — ${e.university}`).join(', '),
    },
    { label: 'Company Matches', render: (c) => <TagList items={c.evaluation?.company_matches} tone="positive" /> },
    {
      label: 'Company Gaps',
      render: (c) => <TagList items={c.evaluation?.company_gaps} tone="negative" />,
    },
    {
      label: 'Hard Requirement Gaps',
      render: (c) => <TagList items={c.evaluation?.missing_requirements} tone="negative" />,
    },
  ]

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link
          to="/candidates"
          className="focus-ring inline-flex items-center gap-1 rounded text-xs font-medium text-brand-600 hover:underline"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to candidates
        </Link>
        <h1 className="mt-1 text-2xl font-bold tracking-tight text-navy-900">Compare Candidates</h1>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full min-w-[640px] text-left">
          <thead>
            <tr className="sticky top-0 border-b border-slate-200 bg-slate-50">
              <th className="px-4 py-3 text-xs font-medium uppercase tracking-wide text-slate-500">Criteria</th>
              {candidates.map((c) => (
                <th key={c.id} className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Avatar name={c.name} size="sm" />
                    <Link
                      to={`/candidates/${c.id}`}
                      className="focus-ring rounded text-sm font-semibold text-navy-900 hover:text-brand-600"
                    >
                      {c.name || 'Unnamed candidate'}
                    </Link>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((row) => (
              <tr key={row.label} className="hover:bg-slate-50">
                <td className="px-4 py-3 text-xs font-medium uppercase tracking-wide text-slate-400">
                  {row.label}
                </td>
                {candidates.map((c) => (
                  <Cell key={c.id}>{row.render(c)}</Cell>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
