import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Mail, Phone, Cake, FileText, ArrowLeft } from 'lucide-react'
import { fetchCandidate } from '../api/candidatesApi'
import { getErrorMessage } from '../api/getErrorMessage'
import Loading from '../components/Loading'
import ErrorBanner from '../components/ErrorBanner'
import Card from '../components/Card'
import AICard from '../components/AICard'
import ScoreBadge from '../components/ScoreBadge'
import MissingFieldTag from '../components/MissingFieldTag'
import Avatar from '../components/Avatar'

function TagList({ items, emptyLabel = 'None listed' }) {
  if (!items || items.length === 0) return <p className="text-sm text-slate-400">{emptyLabel}</p>
  return (
    <div className="flex flex-wrap gap-1.5">
      {items.map((item) => (
        <span key={item} className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
          {item}
        </span>
      ))}
    </div>
  )
}

export default function CandidateDetail() {
  const { candidateId } = useParams()
  const [candidate, setCandidate] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  function load() {
    setLoading(true)
    setError('')
    fetchCandidate(candidateId)
      .then(setCandidate)
      .catch((err) => setError(getErrorMessage(err, 'Could not load candidate')))
      .finally(() => setLoading(false))
  }

  useEffect(load, [candidateId])

  if (loading) return <Loading variant="cards" count={4} />
  if (error) return <ErrorBanner message={error} onRetry={load} />
  if (!candidate) return null

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link
          to="/candidates"
          className="focus-ring inline-flex items-center gap-1 rounded text-xs font-medium text-brand-600 hover:underline"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to candidates
        </Link>
      </div>

      <div className="flex flex-wrap items-start justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-start gap-4">
          <Avatar name={candidate.name} size="lg" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-navy-900">
              {candidate.name || 'Unnamed candidate'}
            </h1>
            <div className="mt-1.5 flex flex-wrap items-center gap-3 text-sm text-slate-500">
              {candidate.email && (
                <span className="flex items-center gap-1">
                  <Mail className="h-3.5 w-3.5" /> {candidate.email}
                </span>
              )}
              {candidate.phone && (
                <span className="flex items-center gap-1">
                  <Phone className="h-3.5 w-3.5" /> {candidate.phone}
                </span>
              )}
              {candidate.age != null && (
                <span className="flex items-center gap-1">
                  <Cake className="h-3.5 w-3.5" /> Age {candidate.age}
                </span>
              )}
            </div>
            {candidate.missing_fields.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {candidate.missing_fields.map((field) => (
                  <MissingFieldTag key={field} field={field} />
                ))}
              </div>
            )}
          </div>
        </div>
        {candidate.resume && (
          <span className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs text-slate-500">
            <FileText className="h-3.5 w-3.5" />
            {candidate.resume.original_filename}
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card title="Skills">
          <TagList items={candidate.skills} />
        </Card>
        <Card title="Programming Languages">
          <TagList items={candidate.programming_languages} />
        </Card>

        <Card title="Education">
          {candidate.education.length === 0 ? (
            <p className="text-sm text-slate-400">None listed</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {candidate.education.map((edu, i) => (
                <li key={i} className="text-sm text-slate-700">
                  <span className="font-medium">{edu.degree}</span> — {edu.university}
                  {edu.year && <span className="text-slate-500"> ({edu.year})</span>}
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title="Certifications">
          <TagList items={candidate.certifications} />
        </Card>

        <Card title="Experience">
          {candidate.experience.length === 0 ? (
            <p className="text-sm text-slate-400">None listed</p>
          ) : (
            <ul className="flex flex-col gap-3">
              {candidate.experience.map((exp, i) => (
                <li key={i} className="text-sm">
                  <p className="font-medium text-slate-700">
                    {exp.title} · {exp.company}
                  </p>
                  <p className="text-xs text-slate-500">
                    {exp.start || '?'} – {exp.end || 'Present'}
                  </p>
                  {exp.description && <p className="mt-1 text-slate-600">{exp.description}</p>}
                </li>
              ))}
            </ul>
          )}
          {candidate.total_experience_years != null && (
            <p className="mt-3 text-xs text-slate-500">
              Total experience: {candidate.total_experience_years} years
            </p>
          )}
        </Card>

        <Card title="Projects">
          {candidate.projects.length === 0 ? (
            <p className="text-sm text-slate-400">None listed</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {candidate.projects.map((proj, i) => (
                <li key={i} className="text-sm">
                  <p className="font-medium text-slate-700">{proj.name}</p>
                  {proj.description && <p className="text-slate-600">{proj.description}</p>}
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <AICard title="AI Analysis">
        {candidate.evaluations.length === 0 ? (
          <p className="text-sm text-slate-400">
            No evaluations yet. Run AI matching from a job&apos;s page to see scores and explanations here.
          </p>
        ) : (
          <div className="flex flex-col gap-4">
            {candidate.evaluations.map((evaluation) => (
              <div key={evaluation.id} className="rounded-xl border border-slate-200 p-4">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-navy-900">{evaluation.job_title}</p>
                  <div className="text-right">
                    <ScoreBadge score={evaluation.overall_score} size="lg" />
                    <p className="mt-0.5 text-[11px] text-slate-400">Overall Match</p>
                  </div>
                </div>
                {evaluation.overall_explanation && (
                  <p className="mt-3 rounded-lg bg-slate-50 p-3 text-sm text-slate-700">
                    {evaluation.overall_explanation}
                  </p>
                )}

                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div className="rounded-lg border border-brand-100 bg-brand-50/60 p-3 text-center">
                    <p className="text-lg font-bold text-brand-700">
                      {evaluation.department_score != null ? `${Math.round(evaluation.department_score)}%` : '—'}
                    </p>
                    <p className="text-xs font-medium text-brand-600">Department Standard Match</p>
                  </div>
                  <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-center">
                    <p className="text-lg font-bold text-navy-900">
                      {evaluation.company_score != null ? `${Math.round(evaluation.company_score)}%` : '—'}
                    </p>
                    <p className="text-xs font-medium text-slate-500">Company Requirement Match</p>
                  </div>
                </div>

                {evaluation.department_breakdown?.length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-navy-700">
                      Department Standard Breakdown
                    </p>
                    <div className="mt-2 flex flex-col gap-3">
                      {evaluation.department_breakdown.map((cat) => (
                        <div key={cat.key} className="rounded-lg border border-slate-200 p-3">
                          <div className="flex flex-wrap items-center justify-between gap-1">
                            <span className="text-sm font-medium text-slate-700">{cat.label}</span>
                            <span className="text-xs text-slate-500">
                              Weight {cat.weight}% · Contribution {cat.contribution}/{cat.weight}
                            </span>
                          </div>
                          <p className="mt-1.5 text-sm text-slate-600">{cat.reason}</p>
                          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                            <div>
                              <p className="mb-1 text-xs font-medium text-emerald-600">Evidence found</p>
                              <TagList items={cat.evidence_found} emptyLabel="No evidence recorded" />
                            </div>
                            <div>
                              <p className="mb-1 text-xs font-medium text-amber-600">Missing</p>
                              <TagList items={cat.missing} emptyLabel="Nothing missing" />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mt-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-navy-700">
                    Company Requirement Alignment
                  </p>
                  {evaluation.company_explanation && (
                    <p className="mt-1 text-sm text-slate-600">{evaluation.company_explanation}</p>
                  )}
                  <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div>
                      <p className="mb-1 text-xs font-medium text-emerald-600">Matched</p>
                      <TagList items={evaluation.company_matches} emptyLabel="No matches recorded" />
                    </div>
                    <div>
                      <p className="mb-1 text-xs font-medium text-amber-600">Gaps</p>
                      <TagList items={evaluation.company_gaps} emptyLabel="No gaps recorded" />
                    </div>
                  </div>
                </div>

                {evaluation.missing_requirements?.length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-amber-600">
                      Hard Requirement Gaps
                    </p>
                    <div className="mt-1">
                      <TagList items={evaluation.missing_requirements} />
                    </div>
                  </div>
                )}

                <p className="mt-4 border-t border-slate-100 pt-3 text-xs text-slate-500">
                  AI recommendation is based on the department's criteria template and this job's own
                  requirements. The recruiter makes the final decision.
                </p>
              </div>
            ))}
          </div>
        )}
      </AICard>
    </div>
  )
}
