import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Search, BookOpen } from 'lucide-react'
import { fetchCriteriaList } from '../api/criteriaApi'
import { getErrorMessage } from '../api/getErrorMessage'
import { useAuth } from '../hooks/useAuth'
import Loading from '../components/Loading'
import ErrorBanner from '../components/ErrorBanner'
import EmptyState from '../components/EmptyState'
import CriteriaCard from '../components/CriteriaCard'
import Button from '../components/Button'
import PageHeader from '../components/PageHeader'

export default function Criteria() {
  const { user } = useAuth()
  const isAdmin = user?.role === 'admin'
  const [criteriaList, setCriteriaList] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [department, setDepartment] = useState('')

  async function load() {
    setLoading(true)
    setError('')
    try {
      setCriteriaList(await fetchCriteriaList())
    } catch (err) {
      setError(getErrorMessage(err, 'Could not load the criteria library'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const departments = useMemo(
    () => [...new Set(criteriaList.map((c) => c.department))].sort(),
    [criteriaList],
  )

  const visibleCriteria = useMemo(() => {
    let rows = criteriaList
    if (department) rows = rows.filter((c) => c.department === department)
    if (search.trim()) {
      const needle = search.toLowerCase()
      rows = rows.filter(
        (c) =>
          c.role_title.toLowerCase().includes(needle) ||
          c.department.toLowerCase().includes(needle) ||
          c.required_skills.some((s) => s.toLowerCase().includes(needle)),
      )
    }
    return rows
  }, [criteriaList, search, department])

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Criteria Library"
        description="Professional competency standards maintained by department admins, used alongside job descriptions to evaluate candidates."
        actions={
          isAdmin && (
            <Link to="/criteria/new">
              <Button icon={Plus}>Add New Criteria</Button>
            </Link>
          )
        }
      />

      <div className="flex flex-wrap gap-3">
        <div className="relative max-w-sm flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by role, department, or skill..."
            className="focus-ring w-full rounded-lg border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-brand-500"
          />
        </div>
        <select
          value={department}
          onChange={(e) => setDepartment(e.target.value)}
          className="focus-ring rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500"
        >
          <option value="">All departments</option>
          {departments.map((dept) => (
            <option key={dept} value={dept}>
              {dept}
            </option>
          ))}
        </select>
      </div>

      <div>
        {loading && <Loading variant="cards" count={3} />}
        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && visibleCriteria.length === 0 && criteriaList.length === 0 && (
          <EmptyState
            icon={BookOpen}
            title="No criteria templates yet"
            description={
              isAdmin
                ? 'Create your first template to give recruiters an objective, department-defined standard for a role.'
                : 'Your department admin has not created any criteria templates yet.'
            }
            action={
              isAdmin && (
                <Link to="/criteria/new">
                  <Button icon={Plus}>Add New Criteria</Button>
                </Link>
              )
            }
          />
        )}

        {!loading && !error && visibleCriteria.length === 0 && criteriaList.length > 0 && (
          <EmptyState icon={Search} title="No templates match your search" description="Try a different search term or filter." />
        )}

        {!loading && !error && visibleCriteria.length > 0 && (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {visibleCriteria.map((criteria) => (
              <CriteriaCard key={criteria.id} criteria={criteria} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
