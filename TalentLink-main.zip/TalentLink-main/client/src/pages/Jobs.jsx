import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Plus, Search, Briefcase, CheckCircle2 } from 'lucide-react'
import { fetchJobs, createJob, updateJob, deleteJob } from '../api/jobsApi'
import { getErrorMessage } from '../api/getErrorMessage'
import { useToast } from '../hooks/useToast'
import Loading from '../components/Loading'
import ErrorBanner from '../components/ErrorBanner'
import EmptyState from '../components/EmptyState'
import JobFormModal from '../components/JobFormModal'
import JobCard from '../components/JobCard'
import ConfirmDialog from '../components/ConfirmDialog'
import Button from '../components/Button'
import PageHeader from '../components/PageHeader'

export default function Jobs() {
  const { showToast } = useToast()
  const [searchParams, setSearchParams] = useSearchParams()
  const [jobs, setJobs] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [editingJob, setEditingJob] = useState(null)
  const [showCreate, setShowCreate] = useState(false)
  const [deletingJob, setDeletingJob] = useState(null)

  async function loadJobs() {
    setLoading(true)
    setError('')
    try {
      setJobs(await fetchJobs())
    } catch (err) {
      setError(getErrorMessage(err, 'Could not load jobs'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadJobs()
  }, [])

  useEffect(() => {
    if (searchParams.get('new') === '1') {
      setShowCreate(true)
      const next = new URLSearchParams(searchParams)
      next.delete('new')
      setSearchParams(next, { replace: true })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const visibleJobs = useMemo(() => {
    if (!search.trim()) return jobs
    const needle = search.toLowerCase()
    return jobs.filter(
      (j) =>
        j.title.toLowerCase().includes(needle) ||
        (j.department || '').toLowerCase().includes(needle) ||
        (j.location || '').toLowerCase().includes(needle),
    )
  }, [jobs, search])

  const openCount = useMemo(() => jobs.filter((j) => j.status === 'open').length, [jobs])

  async function handleCreate(job) {
    const created = await createJob(job)
    setJobs((prev) => [created, ...prev])
    setShowCreate(false)
    showToast(`"${created.title}" was created`)
  }

  async function handleUpdate(job) {
    const updated = await updateJob(editingJob.id, job)
    setJobs((prev) => prev.map((j) => (j.id === updated.id ? updated : j)))
    setEditingJob(null)
    showToast(`"${updated.title}" was updated`)
  }

  async function handleDelete() {
    await deleteJob(deletingJob.id)
    setJobs((prev) => prev.filter((j) => j.id !== deletingJob.id))
    showToast(`"${deletingJob.title}" was deleted`)
    setDeletingJob(null)
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Jobs"
        description="Create and manage open roles."
        actions={
          <Button icon={Plus} onClick={() => setShowCreate(true)}>
            New Job
          </Button>
        }
      />

      {!loading && !error && jobs.length > 0 && (
        <div className="flex flex-wrap gap-4 text-sm">
          <span className="flex items-center gap-1.5 text-slate-500">
            <Briefcase className="h-4 w-4" />
            <strong className="text-navy-900">{jobs.length}</strong> total jobs
          </span>
          <span className="flex items-center gap-1.5 text-slate-500">
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
            <strong className="text-navy-900">{openCount}</strong> open
          </span>
        </div>
      )}

      <div className="relative max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search jobs by title, department, or location..."
          className="focus-ring w-full rounded-lg border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-brand-500"
        />
      </div>

      <div>
        {loading && <Loading variant="cards" count={3} />}
        {!loading && error && <ErrorBanner message={error} onRetry={loadJobs} />}

        {!loading && !error && visibleJobs.length === 0 && jobs.length === 0 && (
          <EmptyState
            icon={Briefcase}
            title="No jobs yet"
            description="Create your first job to start matching candidates against it."
            action={
              <Button icon={Plus} onClick={() => setShowCreate(true)}>
                New Job
              </Button>
            }
          />
        )}

        {!loading && !error && visibleJobs.length === 0 && jobs.length > 0 && (
          <EmptyState icon={Search} title="No jobs match your search" description="Try a different search term." />
        )}

        {!loading && !error && visibleJobs.length > 0 && (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {visibleJobs.map((job) => (
              <JobCard key={job.id} job={job} onEdit={setEditingJob} onDelete={setDeletingJob} />
            ))}
          </div>
        )}
      </div>

      {showCreate && <JobFormModal onClose={() => setShowCreate(false)} onSubmit={handleCreate} />}
      {editingJob && (
        <JobFormModal job={editingJob} onClose={() => setEditingJob(null)} onSubmit={handleUpdate} />
      )}
      {deletingJob && (
        <ConfirmDialog
          title="Delete job"
          message={`Delete "${deletingJob.title}"? This will also remove any match evaluations for this job.`}
          confirmLabel="Delete"
          onConfirm={handleDelete}
          onCancel={() => setDeletingJob(null)}
        />
      )}
    </div>
  )
}
