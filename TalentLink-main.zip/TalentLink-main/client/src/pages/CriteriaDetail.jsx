import { useEffect, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { ArrowLeft, GraduationCap, Clock } from 'lucide-react'
import { fetchCriteria, deleteCriteria } from '../api/criteriaApi'
import { getErrorMessage } from '../api/getErrorMessage'
import { useAuth } from '../hooks/useAuth'
import { useToast } from '../hooks/useToast'
import Loading from '../components/Loading'
import ErrorBanner from '../components/ErrorBanner'
import Card from '../components/Card'
import Button from '../components/Button'
import ConfirmDialog from '../components/ConfirmDialog'

const CATEGORY_FIELDS = [
  { key: 'technical_skills', label: 'Technical Skills' },
  { key: 'experience', label: 'Experience' },
  { key: 'education', label: 'Education' },
  { key: 'portfolio', label: 'Projects / Portfolio' },
  { key: 'competencies', label: 'Professional Competencies' },
]

function TagList({ items, emptyLabel = 'None listed' }) {
  if (!items || items.length === 0) return <p className="text-sm text-slate-400">{emptyLabel}</p>
  return (
    <div className="flex flex-wrap gap-1.5">
      {items.map((item) => (
        <span key={item} className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
          {item}
        </span>
      ))}
    </div>
  )
}

export default function CriteriaDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  const { showToast } = useToast()
  const isAdmin = user?.role === 'admin'
  const [criteria, setCriteria] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [confirmingDelete, setConfirmingDelete] = useState(false)

  function load() {
    setLoading(true)
    setError('')
    fetchCriteria(id)
      .then(setCriteria)
      .catch((err) => setError(getErrorMessage(err, 'Could not load this criteria template')))
      .finally(() => setLoading(false))
  }

  useEffect(load, [id])

  async function handleDelete() {
    await deleteCriteria(id)
    showToast(`"${criteria.role_title}" template was deleted`)
    navigate('/criteria')
  }

  if (loading) return <Loading variant="cards" count={4} />
  if (error) return <ErrorBanner message={error} onRetry={load} />
  if (!criteria) return null

  const rules = criteria.evaluation_rules || {}
  const ageRange =
    criteria.min_age != null || criteria.max_age != null
      ? `${criteria.min_age ?? 'no min'} – ${criteria.max_age ?? 'no max'}`
      : null

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link
          to="/criteria"
          className="focus-ring inline-flex items-center gap-1 rounded text-xs font-medium text-brand-600 hover:underline"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to criteria library
        </Link>
      </div>

      <div className="flex flex-wrap items-start justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div>
          <p className="flex items-center gap-1 text-xs font-medium text-slate-500">
            <GraduationCap className="h-3.5 w-3.5" />
            {criteria.department}
          </p>
          <h1 className="mt-0.5 text-2xl font-bold tracking-tight text-navy-900">{criteria.role_title}</h1>
          {criteria.description && <p className="mt-2 text-sm text-slate-600">{criteria.description}</p>}
          <p className="mt-3 flex items-center gap-1 text-xs text-slate-500">
            <Clock className="h-3.5 w-3.5" />
            {criteria.minimum_experience_years != null
              ? `${criteria.minimum_experience_years}+ years minimum experience`
              : 'No minimum experience specified'}
          </p>
        </div>
        {isAdmin && (
          <div className="flex gap-2">
            <Link to={`/criteria/${id}/edit`}>
              <Button variant="secondary" size="sm">
                Edit
              </Button>
            </Link>
            <Button variant="danger" size="sm" onClick={() => setConfirmingDelete(true)}>
              Delete
            </Button>
          </div>
        )}
      </div>

      <Card title="Qualifications">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <p className="mb-1 text-xs font-medium uppercase text-slate-400">Education Requirements</p>
            <TagList items={criteria.education_requirements} />
          </div>
          <div>
            <p className="mb-1 text-xs font-medium uppercase text-slate-400">Certifications</p>
            <TagList items={criteria.certifications} emptyLabel="None required" />
          </div>
          {ageRange && (
            <div>
              <p className="mb-1 text-xs font-medium uppercase text-slate-400">Age range</p>
              <p className="text-sm text-slate-600">{ageRange}</p>
            </div>
          )}
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card title="Technical Skills — Required">
          <TagList items={criteria.required_skills} />
        </Card>
        <Card title="Technical Skills — Preferred">
          <TagList items={criteria.preferred_skills} />
        </Card>
        <Card title="Professional Competencies">
          <TagList items={criteria.competencies} />
        </Card>
        <Card title="Portfolio Requirements">
          <TagList items={criteria.portfolio_requirements} emptyLabel="No specific portfolio requirements" />
        </Card>
      </div>

      <Card
        title="Evaluation Rules"
        description="How the AI weighs and evaluates each category when scoring a candidate against this template"
      >
        <div className="flex flex-col gap-4">
          {CATEGORY_FIELDS.map(({ key, label }) => {
            const rule = rules[key] || {}
            return (
              <div key={key} className="rounded-lg border border-slate-200 p-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-700">{label}</span>
                  <span className="text-sm font-semibold text-brand-700">{rule.weight ?? 0}%</span>
                </div>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full rounded-full bg-brand-500" style={{ width: `${rule.weight || 0}%` }} />
                </div>
                <p className="mt-2 text-sm text-slate-600">
                  {rule.method || <span className="text-slate-400">No evaluation method specified.</span>}
                </p>
              </div>
            )
          })}
        </div>
      </Card>

      {confirmingDelete && (
        <ConfirmDialog
          title="Delete criteria template"
          message={`Delete "${criteria.role_title}"? Jobs currently linked to it will keep their own data but lose this template link. Past evaluations keep their recorded scores.`}
          confirmLabel="Delete"
          onConfirm={handleDelete}
          onCancel={() => setConfirmingDelete(false)}
        />
      )}
    </div>
  )
}
