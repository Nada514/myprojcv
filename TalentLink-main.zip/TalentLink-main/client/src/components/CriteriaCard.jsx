import { Link } from 'react-router-dom'
import { GraduationCap, Clock } from 'lucide-react'

export default function CriteriaCard({ criteria }) {
  return (
    <div className="animate-slide-up flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="flex items-center gap-1 text-xs font-medium text-slate-500">
            <GraduationCap className="h-3.5 w-3.5" />
            {criteria.department}
          </p>
          <Link
            to={`/criteria/${criteria.id}`}
            className="focus-ring mt-0.5 block rounded font-semibold text-navy-900 hover:text-brand-600"
          >
            {criteria.role_title}
          </Link>
        </div>
      </div>

      <p className="mt-3 line-clamp-2 flex-1 text-sm text-slate-600">
        {criteria.description || 'No description provided.'}
      </p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {criteria.required_skills.slice(0, 4).map((skill) => (
          <span key={skill} className="rounded-full bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-700">
            {skill}
          </span>
        ))}
        {criteria.required_skills.length > 4 && (
          <span className="text-xs text-slate-400">+{criteria.required_skills.length - 4} more</span>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
        <span className="flex items-center gap-1 text-xs text-slate-500">
          <Clock className="h-3.5 w-3.5" />
          {criteria.minimum_experience_years != null
            ? `${criteria.minimum_experience_years}+ yrs experience`
            : 'No minimum experience'}
        </span>
        <Link
          to={`/criteria/${criteria.id}`}
          className="focus-ring rounded text-xs font-medium text-brand-600 hover:underline"
        >
          View Template
        </Link>
      </div>
    </div>
  )
}
