import { Sparkles, CheckCircle2 } from 'lucide-react'
import TechnicalPattern from './TechnicalPattern'
import UniversityBadge from './UniversityBadge'

const benefits = [
  'AI Resume Screening',
  'Smart Candidate Matching',
  'Explainable AI Evaluation',
  'University Recruitment Analytics',
]

export default function AuthLayout({ children }) {
  return (
    <div className="flex min-h-screen bg-canvas">
      <div className="relative hidden w-full max-w-md flex-col justify-between overflow-hidden bg-navy-900 px-10 py-12 text-white lg:flex xl:max-w-lg">
        <TechnicalPattern />
        <div className="pointer-events-none absolute -bottom-32 -right-16 h-80 w-80 rounded-full bg-brand-500/10 blur-3xl" />

        <div className="relative">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-500 text-navy-900">
              <Sparkles className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold tracking-tight">Talent Link</span>
          </div>
          <p className="mt-2 text-xs font-medium uppercase tracking-wide text-slate-400">
            AI-Powered Educational Recruitment Platform
          </p>

          <h2 className="mt-10 text-3xl font-bold leading-tight">
            AI assists recruiters.
            <br /> AI never makes the final call.
          </h2>
          <p className="mt-4 max-w-sm text-sm text-slate-300">
            Connecting university talent with better opportunities using AI — every score comes with a
            clear, human-readable explanation.
          </p>

          <ul className="mt-10 flex flex-col gap-4">
            {benefits.map((b) => (
              <li key={b} className="flex items-start gap-2.5 text-sm text-slate-200">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
                {b}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative flex flex-col gap-3">
          <UniversityBadge tone="dark" className="w-fit" />
          <p className="text-xs text-slate-500">Developed at GUC × GIU</p>
        </div>
      </div>

      <div className="flex flex-1 items-center justify-center px-4 py-12">
        <div className="animate-slide-up w-full max-w-sm">{children}</div>
      </div>
    </div>
  )
}
