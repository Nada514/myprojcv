import { useState } from 'react'
import { X } from 'lucide-react'

export default function TagInput({ label, values, onChange, placeholder, required }) {
  const [draft, setDraft] = useState('')

  function addTag() {
    const tag = draft.trim()
    if (tag && !values.includes(tag)) onChange([...values, tag])
    setDraft('')
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault()
      addTag()
    } else if (e.key === 'Backspace' && !draft && values.length) {
      onChange(values.slice(0, -1))
    }
  }

  function removeTag(tag) {
    onChange(values.filter((v) => v !== tag))
  }

  return (
    <div>
      {label && (
        <label className="text-sm font-medium text-slate-700">
          {label}
          {required && <span className="ml-0.5 text-red-500">*</span>}
        </label>
      )}
      <div className="mt-1 flex flex-wrap items-center gap-1.5 rounded-lg border border-slate-300 px-2 py-1.5 transition-colors focus-within:border-brand-500 focus-within:ring-1 focus-within:ring-brand-500">
        {values.map((tag) => (
          <span
            key={tag}
            className="flex items-center gap-1 rounded-full bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-700"
          >
            {tag}
            <button
              type="button"
              onClick={() => removeTag(tag)}
              className="text-brand-400 hover:text-brand-700"
              aria-label={`Remove ${tag}`}
            >
              <X className="h-3 w-3" />
            </button>
          </span>
        ))}
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={handleKeyDown}
          onBlur={addTag}
          placeholder={values.length ? '' : placeholder}
          className="min-w-[8rem] flex-1 border-none py-0.5 text-sm outline-none"
        />
      </div>
    </div>
  )
}
