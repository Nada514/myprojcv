const palette = [
  'bg-brand-100 text-brand-700',
  'bg-emerald-100 text-emerald-700',
  'bg-amber-100 text-amber-700',
  'bg-ai-100 text-ai-700',
  'bg-navy-100 text-navy-700',
  'bg-rose-100 text-rose-700',
]

function colorFor(seed) {
  let hash = 0
  for (let i = 0; i < seed.length; i++) hash = seed.charCodeAt(i) + ((hash << 5) - hash)
  return palette[Math.abs(hash) % palette.length]
}

function initials(name) {
  if (!name) return '?'
  return name
    .split(' ')
    .map((part) => part[0])
    .filter(Boolean)
    .slice(0, 2)
    .join('')
    .toUpperCase()
}

const sizeClasses = {
  sm: 'h-8 w-8 text-xs',
  md: 'h-10 w-10 text-sm',
  lg: 'h-14 w-14 text-lg',
}

export default function Avatar({ name, size = 'md', className = '', src }) {
  if (src) {
    return (
      <img
        src={src}
        alt={name ? `${name}'s avatar` : 'Avatar'}
        className={`shrink-0 rounded-full object-cover ${sizeClasses[size]} ${className}`}
      />
    )
  }

  return (
    <span
      className={`flex shrink-0 items-center justify-center rounded-full font-semibold ${sizeClasses[size]} ${colorFor(name || '?')} ${className}`}
    >
      {initials(name)}
    </span>
  )
}
