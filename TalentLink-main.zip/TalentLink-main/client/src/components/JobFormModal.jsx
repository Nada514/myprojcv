import { useEffect, useMemo, useState } from 'react'
import { GraduationCap } from 'lucide-react'
import Modal from './Modal'
import ErrorBanner from './ErrorBanner'
import Button from './Button'
import Input from './Input'
import { getErrorMessage } from '../api/getErrorMessage'
import { fetchCriteriaList } from '../api/criteriaApi'

const emptyJob = {
  title: '',
  department: '',
  status: 'open',
  employment_type: '',
  location: '',
  salary_min: '',
  salary_max: '',
  about_role: '',
  responsibilities: '',
  company_info: '',
  team_info: '',
  benefits: '',
  criteria_template_id: null,
}

const EMPLOYMENT_TYPES = ['Full-time', 'Part-time', 'Internship', 'Contract']

function toNumberOrNull(value) {
  if (value === '' || value === null || value === undefined) return null
  return Number(value)
}

const fieldClass =
  'focus-ring mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500'

export default function JobFormModal({ job, onClose, onSubmit }) {
  const [form, setForm] = useState(job ? { ...emptyJob, ...job } : emptyJob)
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [criteriaOptions, setCriteriaOptions] = useState([])

  useEffect(() => {
    fetchCriteriaList()
      .then(setCriteriaOptions)
      .catch(() => setCriteriaOptions([]))
  }, [])

  function update(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  // Templates whose department matches what the recruiter typed are surfaced first as
  // "recommended", so they don't have to hunt through the whole library - they just
  // pick from what their own department already maintains.
  const { suggested, others } = useMemo(() => {
    const dept = (form.department || '').trim().toLowerCase()
    if (!dept) return { suggested: [], others: criteriaOptions }
    const suggested = criteriaOptions.filter((c) => c.department.toLowerCase() === dept)
    const others = criteriaOptions.filter((c) => c.department.toLowerCase() !== dept)
    return { suggested, others }
  }, [criteriaOptions, form.department])

  const selectedCriteria = criteriaOptions.find((c) => c.id === Number(form.criteria_template_id))

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    if (!form.criteria_template_id) {
      setError('Select a criteria template - this is how candidates will be evaluated for this job')
      return
    }
    setSubmitting(true)
    try {
      await onSubmit({
        ...form,
        salary_min: toNumberOrNull(form.salary_min),
        salary_max: toNumberOrNull(form.salary_max),
      })
    } catch (err) {
      setError(getErrorMessage(err, 'Could not save job'))
      setSubmitting(false)
    }
  }

  return (
    <Modal title={job ? 'Edit Job' : 'New Job'} onClose={onClose} wide>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        {error && <ErrorBanner message={error} />}

        <div className="grid grid-cols-2 gap-4">
          <Input
            id="job-title"
            label="Job title"
            required
            value={form.title}
            onChange={(e) => update('title', e.target.value)}
            placeholder="e.g. Frontend Engineer"
          />
          <Input
            id="job-department"
            label="Department"
            value={form.department || ''}
            onChange={(e) => update('department', e.target.value)}
            placeholder="e.g. Engineering"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-slate-700">Employment type</label>
            <select
              value={form.employment_type || ''}
              onChange={(e) => update('employment_type', e.target.value)}
              className={fieldClass}
            >
              <option value="">Not specified</option>
              {EMPLOYMENT_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <Input
            id="job-location"
            label="Location"
            value={form.location || ''}
            onChange={(e) => update('location', e.target.value)}
            placeholder="e.g. Cairo, Egypt / Remote"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700">Status</label>
          <select
            value={form.status || 'open'}
            onChange={(e) => update('status', e.target.value)}
            className={fieldClass}
          >
            <option value="open">Open</option>
            <option value="draft">Draft</option>
            <option value="closed">Closed</option>
          </select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Input
            id="job-salary-min"
            type="number"
            min="0"
            label="Salary min (optional)"
            value={form.salary_min ?? ''}
            onChange={(e) => update('salary_min', e.target.value)}
          />
          <Input
            id="job-salary-max"
            type="number"
            min="0"
            label="Salary max (optional)"
            value={form.salary_max ?? ''}
            onChange={(e) => update('salary_max', e.target.value)}
          />
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700">About the role</label>
          <textarea
            value={form.about_role || ''}
            onChange={(e) => update('about_role', e.target.value)}
            className={fieldClass}
            rows={3}
            placeholder="What this position is and why it exists on the team"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700">Responsibilities</label>
          <textarea
            value={form.responsibilities || ''}
            onChange={(e) => update('responsibilities', e.target.value)}
            className={fieldClass}
            rows={3}
            placeholder="Day-to-day responsibilities for this role"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700">Company information</label>
          <textarea
            value={form.company_info || ''}
            onChange={(e) => update('company_info', e.target.value)}
            className={fieldClass}
            rows={2}
            placeholder="Brief context about the company"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700">Team information</label>
          <textarea
            value={form.team_info || ''}
            onChange={(e) => update('team_info', e.target.value)}
            className={fieldClass}
            rows={2}
            placeholder="Who this role reports to, team size/structure"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700">Benefits (optional)</label>
          <textarea
            value={form.benefits || ''}
            onChange={(e) => update('benefits', e.target.value)}
            className={fieldClass}
            rows={2}
            placeholder="Perks, benefits, PTO policy, etc."
          />
        </div>

        <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
          <label className="text-sm font-medium text-slate-700">
            Criteria template <span className="text-red-500">*</span>
          </label>
          <p className="mt-0.5 text-xs text-slate-500">
            Candidates are evaluated against the department's professional standard, not manually-entered
            skills. Choose the template that matches this role.
          </p>
          <select
            value={form.criteria_template_id ?? ''}
            onChange={(e) => update('criteria_template_id', e.target.value ? Number(e.target.value) : null)}
            className={`${fieldClass} bg-white`}
            required
          >
            <option value="">Select a criteria template...</option>
            {suggested.length > 0 && (
              <optgroup label="Recommended for this department">
                {suggested.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.department} → {c.role_title}
                  </option>
                ))}
              </optgroup>
            )}
            <optgroup label={suggested.length > 0 ? 'Other templates' : 'All templates'}>
              {others.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.department} → {c.role_title}
                </option>
              ))}
            </optgroup>
          </select>
          {selectedCriteria && (
            <div className="mt-3 rounded-lg border border-brand-100 bg-brand-50/50 p-3">
              <p className="flex items-center gap-1 text-xs font-medium text-brand-700">
                <GraduationCap className="h-3.5 w-3.5" />
                {selectedCriteria.department} → {selectedCriteria.role_title}
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {selectedCriteria.required_skills.map((skill) => (
                  <span key={skill} className="rounded-full bg-white px-2 py-0.5 text-xs font-medium text-brand-700">
                    {skill}
                  </span>
                ))}
              </div>
              {selectedCriteria.minimum_experience_years != null && (
                <p className="mt-2 text-xs text-slate-500">
                  Minimum experience: {selectedCriteria.minimum_experience_years} years
                </p>
              )}
            </div>
          )}
        </div>

        <div className="mt-2 flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={submitting}>
            {submitting ? 'Saving...' : job ? 'Save changes' : 'Create job'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
