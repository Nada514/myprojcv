import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AlertTriangle, Trash2 } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import { useToast } from '../hooks/useToast'
import { deleteAccount } from '../api/authApi'
import { getErrorMessage } from '../api/getErrorMessage'
import Card from './Card'
import Button from './Button'
import Modal from './Modal'
import PasswordInput from './PasswordInput'
import ErrorBanner from './ErrorBanner'

export default function DangerZoneCard() {
  const { logout } = useAuth()
  const { showToast } = useToast()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [deleting, setDeleting] = useState(false)

  function closeModal() {
    setOpen(false)
    setPassword('')
    setError('')
  }

  async function handleDelete(e) {
    e.preventDefault()
    setError('')
    setDeleting(true)
    try {
      await deleteAccount(password)
      await logout()
      showToast('Your account has been deleted.')
      navigate('/login', { replace: true })
    } catch (err) {
      setError(getErrorMessage(err, 'Could not delete account'))
      setDeleting(false)
    }
  }

  return (
    <Card title="Danger Zone" description="Irreversible actions.">
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-red-100 bg-red-50/60 p-4">
        <div>
          <p className="text-sm font-medium text-red-700">Delete account</p>
          <p className="mt-0.5 max-w-md text-xs text-red-600">
            Permanently deletes your account and login access. Jobs and candidates you&apos;ve worked on stay in
            the shared workspace for other recruiters.
          </p>
        </div>
        <Button variant="danger" icon={Trash2} onClick={() => setOpen(true)} className="shrink-0">
          Delete account
        </Button>
      </div>

      {open && (
        <Modal title="Delete your account" onClose={closeModal}>
          <form onSubmit={handleDelete} className="flex flex-col gap-4">
            <div className="flex gap-3 rounded-xl border border-red-200 bg-red-50 p-3">
              <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-red-500" />
              <p className="text-sm text-red-700">
                This can&apos;t be undone. Enter your password to confirm permanent deletion of your account.
              </p>
            </div>
            {error && <ErrorBanner message={error} />}
            <PasswordInput
              id="delete-account-password"
              label="Password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoFocus
            />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={closeModal}>
                Cancel
              </Button>
              <Button type="submit" variant="danger" disabled={deleting || !password}>
                {deleting ? 'Deleting...' : 'Permanently delete account'}
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </Card>
  )
}
