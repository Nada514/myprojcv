import { useState } from 'react'
import { changePassword } from '../api/authApi'
import { getErrorMessage } from '../api/getErrorMessage'
import { useToast } from '../hooks/useToast'
import Card from './Card'
import PasswordInput from './PasswordInput'
import Button from './Button'
import ErrorBanner from './ErrorBanner'
import PasswordStrengthMeter from './PasswordStrengthMeter'

const MIN_LENGTH = 8

export default function PasswordChangeForm() {
  const { showToast } = useToast()
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' })
  const [fieldErrors, setFieldErrors] = useState({})
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  function update(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  function validate() {
    const errors = {}
    if (!form.currentPassword) errors.currentPassword = 'Current password is required'
    if (!form.newPassword) errors.newPassword = 'New password is required'
    else if (form.newPassword.length < MIN_LENGTH) errors.newPassword = `Must be at least ${MIN_LENGTH} characters`
    if (form.confirmPassword !== form.newPassword) errors.confirmPassword = 'Passwords do not match'
    setFieldErrors(errors)
    return Object.keys(errors).length === 0
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    if (!validate()) return

    setSaving(true)
    try {
      await changePassword(form)
      showToast('Password changed successfully.')
      setForm({ currentPassword: '', newPassword: '', confirmPassword: '' })
      setFieldErrors({})
    } catch (err) {
      setError(getErrorMessage(err, 'Could not change password'))
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card title="Security" description="Change your password. You'll stay signed in on this device.">
      <form onSubmit={handleSubmit} className="flex max-w-sm flex-col gap-4">
        {error && <ErrorBanner message={error} />}

        <PasswordInput
          id="current-password"
          label="Current password"
          required
          value={form.currentPassword}
          onChange={(e) => update('currentPassword', e.target.value)}
          error={fieldErrors.currentPassword}
        />
        <div>
          <PasswordInput
            id="new-password"
            label="New password"
            required
            value={form.newPassword}
            onChange={(e) => update('newPassword', e.target.value)}
            error={fieldErrors.newPassword}
          />
          <PasswordStrengthMeter password={form.newPassword} />
        </div>
        <PasswordInput
          id="confirm-new-password"
          label="Confirm new password"
          required
          value={form.confirmPassword}
          onChange={(e) => update('confirmPassword', e.target.value)}
          error={fieldErrors.confirmPassword}
        />

        <Button type="submit" disabled={saving} className="w-fit">
          {saving ? 'Saving...' : 'Change password'}
        </Button>
      </form>
    </Card>
  )
}
