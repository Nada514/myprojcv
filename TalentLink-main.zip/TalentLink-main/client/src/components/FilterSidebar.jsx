import { SlidersHorizontal } from 'lucide-react'

const fields = [
  { key: 'skill', label: 'Skills', type: 'text', placeholder: 'e.g. React' },
  { key: 'experience_min', label: 'Min. years experience', type: 'number', placeholder: 'e.g. 2' },
  { key: 'education', label: 'Education', type: 'text', placeholder: 'e.g. Computer Science' },
  { key: 'language', label: 'Programming language', type: 'text', placeholder: 'e.g. Python' },
  { key: 'certification', label: 'Certifications', type: 'text', placeholder: 'e.g. AWS' },
  { key: 'score_min', label: 'Min. match score (%)', type: 'number', placeholder: 'e.g. 70' },
  { key: 'age_min', label: 'Min. age', type: 'number', placeholder: '' },
  { key: 'age_max', label: 'Max. age', type: 'number', placeholder: '' },
]

export default function FilterSidebar({ filters, onChange, onClear }) {
  return (
    <aside className="h-fit w-full shrink-0 rounded-2xl border border-slate-200 bg-white p-4 lg:w-64">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-sm font-semibold text-navy-900">
          <SlidersHorizontal className="h-4 w-4" />
          Filters
        </div>
        <button onClick={onClear} className="focus-ring rounded text-xs font-medium text-brand-600 hover:underline">
          Clear
        </button>
      </div>
      <div className="mt-4 flex flex-col gap-4">
        {fields.map((field) => (
          <div key={field.key}>
            <label className="text-xs font-medium text-slate-500">{field.label}</label>
            <input
              type={field.type}
              value={filters[field.key] || ''}
              onChange={(e) => onChange(field.key, e.target.value)}
              placeholder={field.placeholder}
              className="focus-ring mt-1 w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-sm focus:border-brand-500"
            />
          </div>
        ))}
      </div>
    </aside>
  )
}
