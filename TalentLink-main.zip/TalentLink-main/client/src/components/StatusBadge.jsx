const statusStyles = {
  open: 'bg-emerald-100 text-emerald-700',
  closed: 'bg-slate-200 text-slate-600',
  draft: 'bg-amber-100 text-amber-700',
}

export default function StatusBadge({ status = 'open' }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${
        statusStyles[status] || statusStyles.open
      }`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {status}
    </span>
  )
}
