import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, Briefcase, User } from 'lucide-react'
import { fetchJobs } from '../api/jobsApi'
import { fetchCandidates } from '../api/candidatesApi'

export default function GlobalSearch() {
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState({ jobs: [], candidates: [] })
  const containerRef = useRef(null)

  useEffect(() => {
    function handleClickOutside(e) {
      if (containerRef.current && !containerRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  useEffect(() => {
    const trimmed = query.trim()
    if (trimmed.length < 2) {
      setResults({ jobs: [], candidates: [] })
      return undefined
    }
    const timer = setTimeout(async () => {
      setLoading(true)
      try {
        const [jobs, candidates] = await Promise.all([fetchJobs(), fetchCandidates({})])
        const needle = trimmed.toLowerCase()
        setResults({
          jobs: jobs.filter((j) => j.title.toLowerCase().includes(needle)).slice(0, 5),
          candidates: candidates
            .filter(
              (c) =>
                (c.name || '').toLowerCase().includes(needle) || (c.email || '').toLowerCase().includes(needle),
            )
            .slice(0, 5),
        })
      } catch {
        setResults({ jobs: [], candidates: [] })
      } finally {
        setLoading(false)
      }
    }, 300)
    return () => clearTimeout(timer)
  }, [query])

  const hasResults = results.jobs.length > 0 || results.candidates.length > 0

  function goTo(path) {
    navigate(path)
    setOpen(false)
    setQuery('')
  }

  return (
    <div className="relative w-full max-w-sm" ref={containerRef}>
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
      <input
        value={query}
        onChange={(e) => {
          setQuery(e.target.value)
          setOpen(true)
        }}
        onFocus={() => setOpen(true)}
        placeholder="Search jobs and candidates..."
        aria-label="Search jobs and candidates"
        className="focus-ring w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm text-slate-700 transition-colors placeholder:text-slate-400 focus:border-brand-400 focus:bg-white"
      />

      {open && query.trim().length >= 2 && (
        <div className="animate-scale-in absolute left-0 right-0 z-30 mt-2 max-h-80 overflow-y-auto rounded-xl border border-slate-200 bg-white p-2 shadow-lg">
          {loading && <p className="px-3 py-2 text-xs text-slate-400">Searching...</p>}
          {!loading && !hasResults && (
            <p className="px-3 py-2 text-xs text-slate-400">No matches for &quot;{query}&quot;</p>
          )}

          {!loading && results.jobs.length > 0 && (
            <div className="mb-1">
              <p className="px-3 py-1 text-xs font-semibold uppercase tracking-wide text-slate-400">Jobs</p>
              {results.jobs.map((j) => (
                <button
                  key={j.id}
                  onClick={() => goTo(`/jobs/${j.id}`)}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-slate-700 hover:bg-slate-50"
                >
                  <Briefcase className="h-3.5 w-3.5 text-slate-400" />
                  {j.title}
                </button>
              ))}
            </div>
          )}

          {!loading && results.candidates.length > 0 && (
            <div>
              <p className="px-3 py-1 text-xs font-semibold uppercase tracking-wide text-slate-400">Candidates</p>
              {results.candidates.map((c) => (
                <button
                  key={c.id}
                  onClick={() => goTo(`/candidates/${c.id}`)}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-slate-700 hover:bg-slate-50"
                >
                  <User className="h-3.5 w-3.5 text-slate-400" />
                  {c.name || c.email || 'Unnamed candidate'}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
