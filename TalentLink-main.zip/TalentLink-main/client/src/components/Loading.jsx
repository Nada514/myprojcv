function SkeletonBlock({ className }) {
  return <div className={`animate-pulse rounded-lg bg-slate-200 ${className}`} />
}

export default function Loading({ variant = 'cards', count = 3 }) {
  if (variant === 'table') {
    return (
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
        {Array.from({ length: count }).map((_, i) => (
          <div key={i} className="flex items-center gap-4 border-b border-slate-100 px-4 py-4 last:border-b-0">
            <SkeletonBlock className="h-4 w-1/4" />
            <SkeletonBlock className="h-4 w-1/6" />
            <SkeletonBlock className="h-4 w-1/6" />
            <SkeletonBlock className="h-4 w-1/6" />
          </div>
        ))}
      </div>
    )
  }

  if (variant === 'stats') {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: count }).map((_, i) => (
          <div key={i} className="rounded-2xl border border-slate-200 bg-white p-5">
            <SkeletonBlock className="h-3 w-1/2" />
            <SkeletonBlock className="mt-3 h-8 w-1/3" />
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-3">
            <SkeletonBlock className="h-10 w-10 shrink-0 rounded-full" />
            <div className="flex-1">
              <SkeletonBlock className="h-4 w-2/3" />
              <SkeletonBlock className="mt-2 h-3 w-1/3" />
            </div>
          </div>
          <SkeletonBlock className="mt-4 h-3 w-full" />
          <SkeletonBlock className="mt-2 h-3 w-5/6" />
          <div className="mt-4 flex gap-1.5">
            <SkeletonBlock className="h-5 w-14" />
            <SkeletonBlock className="h-5 w-14" />
          </div>
        </div>
      ))}
    </div>
  )
}
