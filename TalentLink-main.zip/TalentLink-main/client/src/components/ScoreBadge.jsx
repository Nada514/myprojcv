function scoreColor(score) {
  if (score == null) return 'bg-slate-100 text-slate-500'
  if (score >= 80) return 'bg-emerald-100 text-emerald-700'
  if (score >= 60) return 'bg-amber-100 text-amber-700'
  return 'bg-red-100 text-red-700'
}

const sizeClasses = {
  md: 'px-2 py-0.5 text-xs',
  lg: 'px-3 py-1.5 text-sm',
}

export default function ScoreBadge({ score, size = 'md' }) {
  return (
    <span className={`inline-flex items-center rounded-full font-semibold ${sizeClasses[size]} ${scoreColor(score)}`}>
      {score == null ? 'Not scored' : `${Math.round(score)}%`}
    </span>
  )
}
