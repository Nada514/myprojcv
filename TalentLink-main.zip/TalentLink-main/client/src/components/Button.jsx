const variants = {
  primary:
    'bg-heritage-600 text-white shadow-sm hover:bg-heritage-700 hover:shadow disabled:bg-heritage-300 disabled:shadow-none',
  secondary:
    'border border-slate-300 bg-white text-slate-700 hover:border-slate-400 hover:bg-slate-50 disabled:opacity-50',
  gold: 'bg-brand-500 text-navy-900 shadow-sm hover:bg-brand-400 disabled:bg-brand-200 disabled:text-slate-400',
  danger: 'bg-red-600 text-white shadow-sm hover:bg-red-700 disabled:bg-red-300',
  ghost: 'text-slate-500 hover:bg-slate-100 hover:text-slate-700 disabled:opacity-50',
  ai: 'bg-ai-600 text-white shadow-sm hover:bg-ai-700 disabled:bg-ai-300',
}

const sizes = {
  sm: 'px-3 py-1.5 text-xs',
  md: 'px-4 py-2 text-sm',
  lg: 'px-5 py-2.5 text-sm',
}

export default function Button({
  variant = 'primary',
  size = 'md',
  icon: Icon,
  className = '',
  children,
  ...props
}) {
  return (
    <button
      className={`focus-ring inline-flex items-center justify-center gap-1.5 rounded-lg font-medium transition-all duration-150 disabled:cursor-not-allowed active:scale-[0.98] ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {Icon && <Icon className="h-4 w-4" />}
      {children}
    </button>
  )
}
