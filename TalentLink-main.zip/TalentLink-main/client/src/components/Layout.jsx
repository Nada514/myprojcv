import { useState } from 'react'
import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import Navbar from './Navbar'
import SiteFooter from './SiteFooter'

export default function Layout() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false)

  return (
    <div className="flex min-h-screen bg-canvas">
      <Sidebar mobileOpen={mobileNavOpen} onCloseMobile={() => setMobileNavOpen(false)} />
      <div className="flex min-w-0 flex-1 flex-col">
        <Navbar onOpenMobile={() => setMobileNavOpen(true)} />
        <main className="animate-fade-in flex flex-1 flex-col overflow-y-auto px-4 py-6 sm:px-8">
          <div className="flex-1">
            <Outlet />
          </div>
          <SiteFooter />
        </main>
      </div>
    </div>
  )
}
