import { Link, useLocation } from 'react-router-dom'
import { ChevronRight } from 'lucide-react'

const labels = {
  jobs: 'Jobs',
  candidates: 'Candidates',
  compare: 'Compare',
  settings: 'Settings',
}

export default function Breadcrumb() {
  const { pathname } = useLocation()
  const segments = pathname.split('/').filter(Boolean)

  const crumbs = [{ label: 'Jobs', to: '/jobs' }]
  let path = ''
  segments.forEach((seg) => {
    path += `/${seg}`
    const isId = /^\d+$/.test(seg)
    crumbs.push({ label: isId ? 'Details' : labels[seg] || seg, to: path })
  })

  return (
    <nav aria-label="Breadcrumb" className="mb-1 flex items-center gap-1 text-xs font-medium text-slate-400">
      {crumbs.map((c, i) => (
        <span key={c.to} className="flex items-center gap-1">
          {i > 0 && <ChevronRight className="h-3 w-3" />}
          {i === crumbs.length - 1 ? (
            <span className="text-slate-600">{c.label}</span>
          ) : (
            <Link to={c.to} className="hover:text-brand-600">
              {c.label}
            </Link>
          )}
        </span>
      ))}
    </nav>
  )
}
