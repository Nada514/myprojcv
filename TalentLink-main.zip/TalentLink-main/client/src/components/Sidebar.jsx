import { useState } from 'react'
import { NavLink } from 'react-router-dom'
import { Sparkles, ChevronsLeft, ChevronsRight, X } from 'lucide-react'
import { navItems } from '../config/navItems'
import UniversityBadge from './UniversityBadge'

function NavItems({ collapsed, onNavigate }) {
  return (
    <nav className="flex flex-col gap-1 px-3">
      {navItems.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.end}
          onClick={onNavigate}
          title={collapsed ? item.label : undefined}
          className={({ isActive }) =>
            `focus-ring group relative flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
              isActive ? 'bg-white/10 text-brand-400' : 'text-slate-300 hover:bg-white/5 hover:text-white'
            }`
          }
        >
          {({ isActive }) => (
            <>
              {isActive && (
                <span className="absolute left-0 top-1/2 h-5 w-1 -translate-y-1/2 rounded-r-full bg-brand-500" />
              )}
              <item.icon className="h-4 w-4 shrink-0" />
              {!collapsed && item.label}
            </>
          )}
        </NavLink>
      ))}
    </nav>
  )
}

export default function Sidebar({ mobileOpen, onCloseMobile }) {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={`hidden shrink-0 flex-col border-r border-white/10 bg-navy-900 transition-all duration-200 md:flex ${
          collapsed ? 'md:w-[72px]' : 'md:w-60'
        }`}
      >
        <div className={`flex items-center gap-2 px-5 py-5 ${collapsed ? 'justify-center px-0' : ''}`}>
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-500 text-navy-900">
            <Sparkles className="h-4 w-4" />
          </div>
          {!collapsed && (
            <div>
              <span className="block text-lg font-bold leading-tight tracking-tight text-white">Talent Link</span>
              <span className="block text-[11px] font-medium leading-tight text-slate-400">AI Recruitment Platform</span>
            </div>
          )}
        </div>

        <NavItems collapsed={collapsed} />

        <div className="mt-auto flex flex-col gap-3 px-3 py-4">
          <button
            onClick={() => setCollapsed((v) => !v)}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="focus-ring flex items-center justify-center gap-2 rounded-lg py-2 text-xs font-medium text-slate-400 hover:bg-white/5 hover:text-white"
          >
            {collapsed ? <ChevronsRight className="h-4 w-4" /> : <ChevronsLeft className="h-4 w-4" />}
          </button>
          {!collapsed && (
            <div className="flex flex-col items-start gap-2 px-2">
              <UniversityBadge tone="dark" />
              <p className="text-xs text-slate-500">Talent Link MVP · v1.0</p>
            </div>
          )}
        </div>
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="animate-fade-in absolute inset-0 bg-navy-950/50 backdrop-blur-sm" onClick={onCloseMobile} />
          <aside className="animate-slide-up absolute inset-y-0 left-0 flex w-64 flex-col bg-navy-900 shadow-2xl">
            <div className="flex items-center justify-between px-5 py-5">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-500 text-navy-900">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div>
                  <span className="block text-lg font-bold leading-tight tracking-tight text-white">Talent Link</span>
                  <span className="block text-[11px] font-medium leading-tight text-slate-400">AI Recruitment Platform</span>
                </div>
              </div>
              <button
                onClick={onCloseMobile}
                aria-label="Close menu"
                className="focus-ring rounded-lg p-1 text-slate-400 hover:bg-white/5 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <NavItems collapsed={false} onNavigate={onCloseMobile} />
            <div className="mt-auto flex flex-col items-start gap-2 px-5 py-4">
              <UniversityBadge tone="dark" />
              <p className="text-xs text-slate-500">Talent Link MVP · v1.0</p>
            </div>
          </aside>
        </div>
      )}
    </>
  )
}
