import { AlertCircle } from 'lucide-react'

export default function MissingFieldTag({ field }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-700">
      <AlertCircle className="h-3 w-3" />
      Missing: {field.replace(/_/g, ' ')}
    </span>
  )
}
