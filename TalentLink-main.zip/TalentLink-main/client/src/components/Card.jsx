export default function Card({ title, description, action, hoverable = false, className = '', children }) {
  return (
    <div
      className={`rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-shadow ${
        hoverable ? 'hover:shadow-md' : ''
      } ${className}`}
    >
      {(title || action) && (
        <div className="mb-3 flex items-center justify-between gap-2">
          <div>
            {title && <h3 className="text-sm font-semibold text-navy-900">{title}</h3>}
            {description && <p className="mt-0.5 text-xs text-slate-500">{description}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </div>
  )
}
