import { useEffect, useRef, useState } from 'react'
import { Bell, FileText, Briefcase, Target } from 'lucide-react'
import { fetchDashboardSummary } from '../api/dashboardApi'

const activityIcon = {
  resume_uploaded: FileText,
  job_created: Briefcase,
  match_run: Target,
}

export default function NotificationsMenu() {
  const [open, setOpen] = useState(false)
  const [items, setItems] = useState([])
  const [loaded, setLoaded] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    function handleClickOutside(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  function handleOpen() {
    setOpen((v) => !v)
    if (!loaded) {
      fetchDashboardSummary()
        .then((data) => setItems(data.recentActivity.slice(0, 6)))
        .catch(() => setItems([]))
        .finally(() => setLoaded(true))
    }
  }

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={handleOpen}
        aria-label="Notifications"
        className="focus-ring relative flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-700"
      >
        <Bell className="h-4 w-4" />
        {items.length > 0 && <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-brand-500" />}
      </button>

      {open && (
        <div className="animate-scale-in absolute right-0 z-30 mt-2 w-80 rounded-xl border border-slate-200 bg-white py-2 shadow-lg">
          <p className="px-4 pb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Recent Activity</p>
          {!loaded && <p className="px-4 py-3 text-sm text-slate-400">Loading...</p>}
          {loaded && items.length === 0 && <p className="px-4 py-3 text-sm text-slate-400">No recent activity.</p>}
          <ul className="max-h-72 overflow-y-auto">
            {items.map((item, i) => {
              const Icon = activityIcon[item.type] || FileText
              return (
                <li key={i} className="flex items-start gap-2.5 px-4 py-2 hover:bg-slate-50">
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-500">
                    <Icon className="h-3 w-3" />
                  </span>
                  <div>
                    <p className="text-xs text-slate-700">{item.message}</p>
                    <p className="text-[11px] text-slate-400">{new Date(item.timestamp).toLocaleString()}</p>
                  </div>
                </li>
              )
            })}
          </ul>
        </div>
      )}
    </div>
  )
}
