import { useRef, useState } from 'react'
import { Camera } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import { useToast } from '../hooks/useToast'
import { updateProfile as updateProfileRequest, uploadAvatar as uploadAvatarRequest } from '../api/authApi'
import { getErrorMessage } from '../api/getErrorMessage'
import Card from './Card'
import Input from './Input'
import Button from './Button'
import ErrorBanner from './ErrorBanner'
import Avatar from './Avatar'

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const BIO_MAX_LENGTH = 1000

export default function ProfileCard() {
  const { user, updateUser } = useAuth()
  const { showToast } = useToast()
  const fileInputRef = useRef(null)
  const [form, setForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    job_title: user?.job_title || '',
    department: user?.department || '',
    bio: user?.bio || '',
  })
  const [error, setError] = useState('')
  const [fieldErrors, setFieldErrors] = useState({})
  const [saving, setSaving] = useState(false)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)

  function update(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  function validate() {
    const errors = {}
    if (!form.name.trim()) errors.name = 'Full name is required'
    if (!form.email.trim()) errors.email = 'Email is required'
    else if (!EMAIL_REGEX.test(form.email.trim())) errors.email = 'Enter a valid email address'
    if (form.bio.length > BIO_MAX_LENGTH) errors.bio = `Bio must be ${BIO_MAX_LENGTH} characters or fewer`
    setFieldErrors(errors)
    return Object.keys(errors).length === 0
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    if (!validate()) return

    setSaving(true)
    try {
      const updated = await updateProfileRequest({
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim() || null,
        job_title: form.job_title.trim() || null,
        department: form.department.trim() || null,
        bio: form.bio.trim() || null,
      })
      updateUser(updated)
      showToast('Profile updated successfully.')
    } catch (err) {
      setError(getErrorMessage(err, 'Could not update profile'))
    } finally {
      setSaving(false)
    }
  }

  async function handleAvatarChange(e) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return

    setUploadingAvatar(true)
    try {
      const updated = await uploadAvatarRequest(file)
      updateUser(updated)
      showToast('Profile picture updated.')
    } catch (err) {
      showToast(getErrorMessage(err, 'Could not upload image'), 'error')
    } finally {
      setUploadingAvatar(false)
    }
  }

  return (
    <Card title="Personal Information" description="Your profile as recruiters and hiring managers will see it.">
      <div className="mb-6 flex items-center gap-4">
        <div className="relative">
          <Avatar name={user?.name} src={user?.profile_image} size="lg" />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploadingAvatar}
            aria-label="Change profile picture"
            className="focus-ring absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full border-2 border-white bg-brand-600 text-white hover:bg-brand-700 disabled:opacity-50"
          >
            <Camera className="h-3 w-3" />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
            onChange={handleAvatarChange}
          />
        </div>
        <div>
          <p className="text-sm font-medium text-navy-900">{user?.name}</p>
          <p className="text-xs text-slate-500">
            {user?.job_title || 'No title set'}
            {user?.department ? ` · ${user.department}` : ''}
          </p>
          {uploadingAvatar && <p className="mt-0.5 text-xs text-brand-600">Uploading...</p>}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        {error && <ErrorBanner message={error} />}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input
            id="profile-name"
            label="Full name"
            required
            value={form.name}
            onChange={(e) => update('name', e.target.value)}
            error={fieldErrors.name}
          />
          <Input
            id="profile-email"
            type="email"
            label="Email address"
            required
            value={form.email}
            onChange={(e) => update('email', e.target.value)}
            error={fieldErrors.email}
          />
          <Input
            id="profile-phone"
            label="Phone number"
            value={form.phone}
            onChange={(e) => update('phone', e.target.value)}
            placeholder="+20 100 000 0000"
          />
          <Input
            id="profile-job-title"
            label="Job title"
            value={form.job_title}
            onChange={(e) => update('job_title', e.target.value)}
            placeholder="e.g. Recruitment Specialist"
          />
          <Input
            id="profile-department"
            label="Department"
            value={form.department}
            onChange={(e) => update('department', e.target.value)}
            placeholder="e.g. Engineering"
            className="sm:col-span-2"
          />
        </div>

        <div>
          <label htmlFor="profile-bio" className="text-sm font-medium text-slate-700">
            Bio
          </label>
          <textarea
            id="profile-bio"
            value={form.bio}
            onChange={(e) => update('bio', e.target.value)}
            rows={3}
            maxLength={BIO_MAX_LENGTH}
            placeholder="A short introduction other recruiters will see"
            className="focus-ring mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500"
          />
          <div className="mt-1 flex items-center justify-between">
            {fieldErrors.bio ? (
              <p className="text-xs text-red-600">{fieldErrors.bio}</p>
            ) : (
              <span />
            )}
            <p className="text-xs text-slate-400">
              {form.bio.length}/{BIO_MAX_LENGTH}
            </p>
          </div>
        </div>

        <div>
          <Button type="submit" disabled={saving} className="w-fit">
            {saving ? 'Saving...' : 'Save changes'}
          </Button>
        </div>
      </form>
    </Card>
  )
}
