export default function UniversityBadge({ className = '', tone = 'light' }) {
  const toneClass =
    tone === 'dark'
      ? 'border-white/10 bg-white/5 text-navy-100'
      : 'border-slate-200 bg-slate-50 text-slate-500'

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium ${toneClass} ${className}`}
    >
      <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-gradient-to-br from-heritage-500 to-navy-700" />
      GUC × GIU Innovation Project
    </span>
  )
}
