import UniversityBadge from './UniversityBadge'

export default function SiteFooter() {
  return (
    <footer className="mt-10 border-t border-slate-200 px-4 py-5 text-center sm:px-8">
      <p className="text-xs font-semibold text-navy-900">Talent Link</p>
      <p className="mt-0.5 text-xs text-slate-400">
        AI-Assisted Recruitment System · University Innovation Project
      </p>
      <div className="mt-2 flex justify-center">
        <UniversityBadge />
      </div>
    </footer>
  )
}
