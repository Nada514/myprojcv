function scorePassword(pw) {
  let score = 0
  if (pw.length >= 8) score++
  if (pw.length >= 12) score++
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++
  if (/\d/.test(pw)) score++
  if (/[^A-Za-z0-9]/.test(pw)) score++
  return Math.min(score, 4)
}

const labels = ['Weak', 'Fair', 'Good', 'Strong']
const colors = ['bg-red-500', 'bg-amber-500', 'bg-brand-500', 'bg-emerald-500']

export default function PasswordStrengthMeter({ password }) {
  if (!password) return null
  const level = Math.max(scorePassword(password) - 1, 0)

  return (
    <div className="mt-1.5">
      <div className="flex gap-1">
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={`h-1 flex-1 rounded-full transition-colors ${i <= level ? colors[level] : 'bg-slate-200'}`} />
        ))}
      </div>
      <p className="mt-1 text-xs text-slate-400">{labels[level]}</p>
    </div>
  )
}
