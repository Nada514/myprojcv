// Subtle engineering-blueprint backdrop: a fine grid plus a handful of connected
// "network nodes", evoking precision/AI without illustration or gradients.
export default function TechnicalPattern({ className = '' }) {
  const nodes = [
    [40, 60],
    [140, 30],
    [230, 90],
    [90, 160],
    [200, 200],
    [60, 250],
  ]
  const edges = [
    [0, 1],
    [1, 2],
    [0, 3],
    [2, 4],
    [3, 4],
    [3, 5],
  ]

  return (
    <svg
      className={`pointer-events-none absolute inset-0 h-full w-full ${className}`}
      viewBox="0 0 280 320"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <pattern id="tl-grid" width="28" height="28" patternUnits="userSpaceOnUse">
          <path d="M 28 0 L 0 0 0 28" fill="none" stroke="white" strokeOpacity="0.06" strokeWidth="1" />
        </pattern>
      </defs>
      <rect width="280" height="320" fill="url(#tl-grid)" />
      {edges.map(([a, b], i) => (
        <line
          key={i}
          x1={nodes[a][0]}
          y1={nodes[a][1]}
          x2={nodes[b][0]}
          y2={nodes[b][1]}
          stroke="white"
          strokeOpacity="0.12"
          strokeWidth="1"
        />
      ))}
      {nodes.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={i === 4 ? 3.5 : 2.5} fill="white" fillOpacity="0.25" />
      ))}
    </svg>
  )
}
