import Card from './Card'

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between border-b border-slate-100 py-2.5 last:border-b-0">
      <span className="text-sm text-slate-500">{label}</span>
      <span className="text-sm font-medium text-navy-900">{value}</span>
    </div>
  )
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1)
}

function formatDate(value) {
  if (!value) return '—'
  return new Date(value).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })
}

function formatDateTime(value) {
  if (!value) return 'This session'
  return new Date(value).toLocaleString()
}

export default function AccountInfoCard({ user }) {
  const role = user?.role || 'recruiter'

  return (
    <Card title="Account Information" description="Read-only details managed by Talent Link.">
      <div className="flex flex-col">
        <Row label="Account ID" value={`#${user?.id ?? '—'}`} />
        <Row label="Account type" value={`${capitalize(role)} Account`} />
        <Row label="Role" value={capitalize(role)} />
        <Row label="Member since" value={formatDate(user?.created_at)} />
        <Row label="Last login" value={formatDateTime(user?.last_login_at)} />
      </div>
    </Card>
  )
}
