import { useEffect, useRef, useState } from 'react'
import { NavLink } from 'react-router-dom'
import { ChevronDown, LogOut, Menu, Settings as SettingsIcon, Sparkles } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import Avatar from './Avatar'
import Breadcrumb from './Breadcrumb'
import GlobalSearch from './GlobalSearch'
import NotificationsMenu from './NotificationsMenu'

export default function Navbar({ onOpenMobile }) {
  const { user, logout } = useAuth()
  const [open, setOpen] = useState(false)
  const menuRef = useRef(null)

  useEffect(() => {
    function handleClickOutside(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm">
      <div className="flex items-center gap-3 px-4 py-3 sm:px-8">
        <button
          onClick={onOpenMobile}
          aria-label="Open menu"
          className="focus-ring flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 md:hidden"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-2 md:hidden">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-white">
            <Sparkles className="h-4 w-4" />
          </div>
        </div>

        <div className="hidden md:block">
          <Breadcrumb />
        </div>

        <div className="hidden flex-1 justify-center md:flex">
          <GlobalSearch />
        </div>

        <div className="ml-auto flex items-center gap-1.5">
          <NotificationsMenu />

          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setOpen((v) => !v)}
              className="focus-ring flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-slate-100"
            >
              <Avatar name={user?.name} src={user?.profile_image} size="sm" />
              <span className="hidden text-left sm:block">
                <span className="block text-sm font-medium text-slate-700">{user?.name}</span>
                <span className="block text-xs text-slate-400">{user?.email}</span>
              </span>
              <ChevronDown className="h-4 w-4 text-slate-400" />
            </button>

            {open && (
              <div className="animate-scale-in absolute right-0 z-20 mt-2 w-48 rounded-xl border border-slate-200 bg-white py-1 shadow-lg">
                <NavLink
                  to="/settings"
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-2 px-4 py-2 text-sm text-slate-600 hover:bg-slate-50"
                >
                  <SettingsIcon className="h-4 w-4" />
                  Settings
                </NavLink>
                <button
                  onClick={logout}
                  className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50"
                >
                  <LogOut className="h-4 w-4" />
                  Log out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="px-4 pb-3 md:hidden">
        <GlobalSearch />
      </div>
    </header>
  )
}
