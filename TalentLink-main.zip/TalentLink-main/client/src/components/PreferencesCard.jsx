import { useState } from 'react'
import { Mail, Sparkles, LayoutDashboard } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import { useToast } from '../hooks/useToast'
import { updatePreferences } from '../api/authApi'
import { getErrorMessage } from '../api/getErrorMessage'
import Card from './Card'

function Toggle({ checked, onChange, disabled, label }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      disabled={disabled}
      className={`focus-ring relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:opacity-50 ${
        checked ? 'bg-brand-600' : 'bg-slate-200'
      }`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
          checked ? 'translate-x-5' : 'translate-x-0.5'
        }`}
      />
    </button>
  )
}

const items = [
  {
    key: 'emailNotifications',
    icon: Mail,
    label: 'Email notifications',
    description: 'Saved to your account (email delivery is not yet wired up in this environment).',
  },
  {
    key: 'aiEvaluationNotifications',
    icon: Sparkles,
    label: 'AI evaluation notifications',
    description: 'Get notified in-app when AI matching finishes running.',
  },
  {
    key: 'defaultSortByScore',
    icon: LayoutDashboard,
    label: 'Sort candidates by match score by default',
    description: 'Applied automatically the next time you open the Candidates page.',
  },
]

export default function PreferencesCard() {
  const { user, updateUser } = useAuth()
  const { showToast } = useToast()
  const [savingKey, setSavingKey] = useState(null)

  async function handleToggle(key, value) {
    setSavingKey(key)
    try {
      const updated = await updatePreferences({ [key]: value })
      updateUser(updated)
    } catch (err) {
      showToast(getErrorMessage(err, 'Could not save preference'), 'error')
    } finally {
      setSavingKey(null)
    }
  }

  return (
    <Card title="Preferences" description="Personal preferences saved to your account.">
      <div className="flex flex-col divide-y divide-slate-100">
        {items.map((item) => (
          <div key={item.key} className="flex items-center justify-between gap-4 py-3 first:pt-0 last:pb-0">
            <div className="flex items-start gap-3">
              <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                <item.icon className="h-4 w-4" />
              </span>
              <div>
                <p className="text-sm font-medium text-navy-900">{item.label}</p>
                <p className="text-xs text-slate-500">{item.description}</p>
              </div>
            </div>
            <Toggle
              label={item.label}
              checked={Boolean(user?.preferences?.[item.key])}
              onChange={(value) => handleToggle(item.key, value)}
              disabled={savingKey === item.key}
            />
          </div>
        ))}
      </div>
    </Card>
  )
}
