import { Sparkles } from 'lucide-react'

export default function SplashScreen({ leaving = false }) {
  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center gap-5 bg-navy-900 transition-opacity duration-500 ${
        leaving ? 'pointer-events-none opacity-0' : 'opacity-100'
      }`}
    >
      <div className="animate-splash-pop flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-500 text-navy-900 shadow-lg shadow-brand-500/20">
        <Sparkles className="h-8 w-8" />
      </div>
      <div className="animate-splash-fade flex flex-col items-center gap-1.5 text-center">
        <span className="text-2xl font-bold tracking-tight text-white">Talent Link</span>
        <span className="text-xs font-medium uppercase tracking-widest text-slate-400">
          AI-Powered Educational Recruitment Platform
        </span>
      </div>
      <div className="animate-splash-fade mt-2 h-1 w-40 overflow-hidden rounded-full bg-white/10">
        <div className="h-full w-1/3 animate-splash-bar rounded-full bg-brand-500" />
      </div>
    </div>
  )
}
