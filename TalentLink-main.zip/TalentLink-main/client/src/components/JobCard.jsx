import { Link } from 'react-router-dom'
import { Users, Building2, MapPin, Briefcase } from 'lucide-react'
import StatusBadge from './StatusBadge'

export default function JobCard({ job, onEdit, onDelete }) {
  return (
    <div className="animate-slide-up flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex items-start justify-between gap-2">
        <div>
          <Link to={`/jobs/${job.id}`} className="focus-ring rounded font-semibold text-navy-900 hover:text-brand-600">
            {job.title}
          </Link>
          <p className="mt-0.5 flex items-center gap-1 text-xs text-slate-500">
            <Building2 className="h-3 w-3" />
            {job.department || 'No department'}
          </p>
        </div>
        <StatusBadge status={job.status} />
      </div>

      <p className="mt-3 line-clamp-3 flex-1 text-sm text-slate-600">
        {job.about_role || 'No description provided.'}
      </p>

      <div className="mt-3 flex flex-wrap gap-3 text-xs text-slate-500">
        {job.employment_type && (
          <span className="flex items-center gap-1">
            <Briefcase className="h-3.5 w-3.5" /> {job.employment_type}
          </span>
        )}
        {job.location && (
          <span className="flex items-center gap-1">
            <MapPin className="h-3.5 w-3.5" /> {job.location}
          </span>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
        <Link
          to={`/jobs/${job.id}`}
          className="focus-ring flex items-center gap-1 rounded text-xs font-medium text-brand-600 hover:underline"
        >
          <Users className="h-3.5 w-3.5" />
          View candidates
        </Link>
        <div className="flex gap-3">
          <button
            onClick={() => onEdit(job)}
            className="focus-ring rounded text-xs font-medium text-slate-500 hover:text-slate-700"
          >
            Edit
          </button>
          <button
            onClick={() => onDelete(job)}
            className="focus-ring rounded text-xs font-medium text-red-500 hover:text-red-700"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  )
}
