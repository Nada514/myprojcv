import { useState } from 'react'
import { CheckCircle2, XCircle, Sparkles, X, RotateCcw } from 'lucide-react'
import Modal from './Modal'
import FileDropzone from './FileDropzone'
import ErrorBanner from './ErrorBanner'
import Button from './Button'
import { uploadResumes, retryResumeExtraction } from '../api/resumesApi'
import { getErrorMessage } from '../api/getErrorMessage'

// A resume can end in three real terminal states (plus 'pending' while a request is
// in flight) - this must match what the backend actually records, not imply a
// "still working on it" state that will never resolve on its own.
function resultStatus(r) {
  if (r.candidate_id) {
    return { label: 'Candidate extracted', tone: 'success', detail: null }
  }
  if (r.parse_status === 'ai_failed') {
    return { label: 'AI extraction failed', tone: 'ai', detail: r.error_message, retryable: true }
  }
  if (r.parse_status === 'failed') {
    return { label: 'Could not read file', tone: 'error', detail: r.error_message, retryable: false }
  }
  return { label: 'Processing...', tone: 'pending', detail: null }
}

const toneStyles = {
  success: { icon: CheckCircle2, className: 'text-emerald-600' },
  ai: { icon: Sparkles, className: 'text-ai-600' },
  error: { icon: XCircle, className: 'text-red-600' },
  pending: { icon: null, className: 'text-slate-400' },
}

export default function ResumeUploadModal({ onClose, onUploaded }) {
  const [selectedFiles, setSelectedFiles] = useState([])
  const [results, setResults] = useState([])
  const [uploading, setUploading] = useState(false)
  const [retryingId, setRetryingId] = useState(null)
  const [error, setError] = useState('')

  function handleFilesSelected(fileList) {
    setSelectedFiles((prev) => [...prev, ...Array.from(fileList)])
  }

  async function handleUpload() {
    setError('')
    setUploading(true)
    try {
      const uploaded = await uploadResumes(selectedFiles)
      setResults((prev) => [...uploaded, ...prev])
      setSelectedFiles([])
      onUploaded?.(uploaded)
    } catch (err) {
      setError(getErrorMessage(err, 'Upload failed'))
    } finally {
      setUploading(false)
    }
  }

  async function handleRetry(resumeId) {
    setRetryingId(resumeId)
    try {
      const updated = await retryResumeExtraction(resumeId)
      setResults((prev) => prev.map((r) => (r.id === resumeId ? updated : r)))
      onUploaded?.([updated])
    } catch (err) {
      setError(getErrorMessage(err, 'Retry failed'))
    } finally {
      setRetryingId(null)
    }
  }

  return (
    <Modal title="Upload Resumes" onClose={onClose} wide>
      <div className="flex flex-col gap-4">
        {error && <ErrorBanner message={error} />}

        <FileDropzone onFilesSelected={handleFilesSelected} />

        {selectedFiles.length > 0 && (
          <ul className="flex flex-col gap-1 rounded-xl border border-slate-200 p-3 text-sm">
            {selectedFiles.map((file, idx) => (
              <li key={`${file.name}-${idx}`} className="flex items-center justify-between">
                <span className="truncate text-slate-700">{file.name}</span>
                <button
                  type="button"
                  onClick={() => setSelectedFiles((prev) => prev.filter((_, i) => i !== idx))}
                  className="focus-ring rounded text-xs text-slate-400 hover:text-red-500"
                  aria-label={`Remove ${file.name}`}
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ul>
        )}

        {uploading && (
          <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-600">
            <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-slate-300 border-t-brand-500" />
            Uploading and processing with AI - this can take a moment per resume...
          </div>
        )}

        {results.length > 0 && (
          <div className="rounded-xl border border-slate-200 p-3">
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-slate-400">Upload results</p>
            <ul className="flex flex-col gap-2 text-sm">
              {results.map((r) => {
                const status = resultStatus(r)
                const { icon: Icon, className } = toneStyles[status.tone]
                return (
                  <li key={r.id} className="rounded-lg border border-slate-100 px-3 py-2">
                    <div className="flex items-center justify-between gap-3">
                      <span className="truncate text-slate-700">{r.original_filename}</span>
                      <span className={`flex shrink-0 items-center gap-1 text-xs font-medium ${className}`}>
                        {Icon ? <Icon className="h-3.5 w-3.5" /> : null}
                        {status.label}
                      </span>
                    </div>
                    {status.detail && <p className="mt-1 text-xs text-slate-500">{status.detail}</p>}
                    {status.retryable && (
                      <button
                        type="button"
                        onClick={() => handleRetry(r.id)}
                        disabled={retryingId === r.id}
                        className="focus-ring mt-1.5 flex items-center gap-1 rounded text-xs font-medium text-ai-600 hover:underline disabled:opacity-50"
                      >
                        <RotateCcw className="h-3 w-3" />
                        {retryingId === r.id ? 'Retrying...' : 'Retry AI extraction'}
                      </button>
                    )}
                  </li>
                )
              })}
            </ul>
          </div>
        )}

        <div className="mt-2 flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Close
          </Button>
          <Button type="button" onClick={handleUpload} disabled={uploading || selectedFiles.length === 0}>
            {uploading ? 'Uploading...' : `Upload ${selectedFiles.length || ''} resume${selectedFiles.length === 1 ? '' : 's'}`}
          </Button>
        </div>
      </div>
    </Modal>
  )
}
