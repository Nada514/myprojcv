import { Link } from 'react-router-dom'
import { Briefcase } from 'lucide-react'
import ScoreBadge from './ScoreBadge'
import MissingFieldTag from './MissingFieldTag'
import Avatar from './Avatar'

export default function CandidateCard({ candidate, selected, onToggleSelect, onDelete }) {
  const topSkills = [...candidate.programming_languages, ...candidate.skills].slice(0, 4)

  return (
    <div
      className={`animate-slide-up flex flex-col rounded-2xl border bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md ${
        selected ? 'border-brand-400 ring-1 ring-brand-400' : 'border-slate-200'
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <label className="flex items-start gap-3">
          <input
            type="checkbox"
            checked={selected}
            onChange={onToggleSelect}
            className="mt-3 rounded border-slate-300 text-brand-600 focus:ring-brand-500"
            aria-label={`Select ${candidate.name || 'candidate'}`}
          />
          <Avatar name={candidate.name} />
          <div>
            <Link to={`/candidates/${candidate.id}`} className="focus-ring rounded font-semibold text-navy-900 hover:text-brand-600">
              {candidate.name || 'Unnamed candidate'}
            </Link>
            <p className="text-xs text-slate-500">{candidate.email || 'No email extracted'}</p>
          </div>
        </label>
        <ScoreBadge score={candidate.best_score} />
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {topSkills.length === 0 && <span className="text-xs text-slate-400">No skills extracted</span>}
        {topSkills.map((skill) => (
          <span key={skill} className="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-600">
            {skill}
          </span>
        ))}
      </div>

      <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-500">
        <Briefcase className="h-3.5 w-3.5" />
        {candidate.total_experience_years != null ? `${candidate.total_experience_years} years experience` : 'Experience not specified'}
      </div>

      {candidate.missing_fields.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          <MissingFieldTag field={candidate.missing_fields[0]} />
          {candidate.missing_fields.length > 1 && (
            <span className="text-xs text-slate-400">+{candidate.missing_fields.length - 1} more</span>
          )}
        </div>
      )}

      <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
        <Link
          to={`/candidates/${candidate.id}`}
          className="focus-ring rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
        >
          View profile
        </Link>
        <button onClick={onDelete} className="focus-ring rounded text-xs font-medium text-red-500 hover:text-red-700">
          Delete
        </button>
      </div>
    </div>
  )
}
