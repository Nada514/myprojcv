import apiClient from './client'

export async function register(name, email, password, confirmPassword) {
  const { data } = await apiClient.post('/auth/register', { name, email, password, confirmPassword })
  return data
}

export async function login(email, password, rememberMe) {
  const { data } = await apiClient.post('/auth/login', { email, password, rememberMe })
  return data
}

export async function logout() {
  await apiClient.post('/auth/logout')
}

export async function fetchCurrentUser() {
  const { data } = await apiClient.get('/auth/me')
  return data
}

export async function fetchProfile() {
  const { data } = await apiClient.get('/auth/profile')
  return data
}

export async function updateProfile(payload) {
  const { data } = await apiClient.put('/auth/profile', payload)
  return data
}

export async function updatePreferences(preferences) {
  const { data } = await apiClient.put('/auth/preferences', { preferences })
  return data
}

export async function changePassword(payload) {
  await apiClient.put('/auth/change-password', payload)
}

export async function uploadAvatar(file) {
  const formData = new FormData()
  formData.append('avatar', file)
  const { data } = await apiClient.post('/auth/profile/avatar', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return data
}

export async function deleteAccount(password) {
  await apiClient.delete('/auth/account', { data: { password } })
}
