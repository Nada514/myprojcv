import apiClient from './client'

export async function runMatch(jobId, candidateIds) {
  const { data } = await apiClient.post(`/jobs/${jobId}/match`, candidateIds ? { candidateIds } : {})
  return data
}

export async function fetchJobEvaluations(jobId) {
  const { data } = await apiClient.get(`/jobs/${jobId}/evaluations`, { params: { sort: 'score' } })
  return data
}
