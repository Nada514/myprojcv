import apiClient from './client'

export async function uploadResumes(files, onUploadProgress) {
  const formData = new FormData()
  Array.from(files).forEach((file) => formData.append('resumes', file))

  const { data } = await apiClient.post('/resumes/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress,
  })
  return data
}

export async function fetchResumes() {
  const { data } = await apiClient.get('/resumes')
  return data
}

export async function retryResumeExtraction(id) {
  const { data } = await apiClient.post(`/resumes/${id}/retry`)
  return data
}
