import apiClient from './client'

export async function compareCandidates(candidateIds, jobId) {
  const { data } = await apiClient.post('/compare', { candidateIds, jobId })
  return data
}
