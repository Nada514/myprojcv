import apiClient from './client'

export async function fetchCriteriaList(params) {
  const { data } = await apiClient.get('/criteria', { params })
  return data
}

export async function fetchCriteria(id) {
  const { data } = await apiClient.get(`/criteria/${id}`)
  return data
}

export async function createCriteria(criteria) {
  const { data } = await apiClient.post('/criteria', criteria)
  return data
}

export async function updateCriteria(id, criteria) {
  const { data } = await apiClient.put(`/criteria/${id}`, criteria)
  return data
}

export async function deleteCriteria(id) {
  await apiClient.delete(`/criteria/${id}`)
}
