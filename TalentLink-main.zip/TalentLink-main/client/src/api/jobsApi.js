import apiClient from './client'

export async function fetchJobs() {
  const { data } = await apiClient.get('/jobs')
  return data
}

export async function fetchJob(id) {
  const { data } = await apiClient.get(`/jobs/${id}`)
  return data
}

export async function createJob(job) {
  const { data } = await apiClient.post('/jobs', job)
  return data
}

export async function updateJob(id, job) {
  const { data } = await apiClient.put(`/jobs/${id}`, job)
  return data
}

export async function deleteJob(id) {
  await apiClient.delete(`/jobs/${id}`)
}
