import apiClient from './client'

export async function fetchCandidates(filters = {}) {
  const params = Object.fromEntries(
    Object.entries(filters).filter(([, v]) => v !== '' && v != null),
  )
  const { data } = await apiClient.get('/candidates', { params })
  return data
}

export async function fetchCandidate(id) {
  const { data } = await apiClient.get(`/candidates/${id}`)
  return data
}

export async function deleteCandidate(id) {
  await apiClient.delete(`/candidates/${id}`)
}
