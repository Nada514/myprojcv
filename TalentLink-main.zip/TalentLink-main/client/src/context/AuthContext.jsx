import { useEffect, useState, useCallback } from 'react'
import {
  login as loginRequest,
  logout as logoutRequest,
  register as registerRequest,
  fetchCurrentUser,
} from '../api/authApi'
import { AuthContext } from './authContextInstance'

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchCurrentUser()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setLoading(false))
  }, [])

  const login = useCallback(async (email, password, rememberMe) => {
    const loggedInUser = await loginRequest(email, password, rememberMe)
    setUser(loggedInUser)
    return loggedInUser
  }, [])

  const register = useCallback(async (name, email, password, confirmPassword) => {
    // Intentionally does not set the user / establish a session here - registration
    // redirects to the login page so the user authenticates explicitly afterward.
    return registerRequest(name, email, password, confirmPassword)
  }, [])

  const logout = useCallback(async () => {
    await logoutRequest()
    setUser(null)
  }, [])

  // Lets profile/preferences forms push a freshly-saved user object into
  // context immediately, without a round-trip refetch.
  const updateUser = useCallback((updatedUser) => {
    setUser(updatedUser)
  }, [])

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  )
}
