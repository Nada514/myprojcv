import { useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { ToastProvider } from './context/ToastContext'
import ProtectedRoute from './components/ProtectedRoute'
import Layout from './components/Layout'
import SplashScreen from './components/SplashScreen'
import Login from './pages/Login'
import Register from './pages/Register'
import Jobs from './pages/Jobs'
import JobDetail from './pages/JobDetail'
import Candidates from './pages/Candidates'
import CandidateDetail from './pages/CandidateDetail'
import Compare from './pages/Compare'
import Settings from './pages/Settings'
import Criteria from './pages/Criteria'
import CriteriaDetail from './pages/CriteriaDetail'
import CriteriaForm from './pages/CriteriaForm'

const SPLASH_DURATION_MS = 2200

function App() {
  const [showSplash, setShowSplash] = useState(true)
  const [splashLeaving, setSplashLeaving] = useState(false)

  useEffect(() => {
    const leaveTimer = setTimeout(() => setSplashLeaving(true), SPLASH_DURATION_MS)
    const removeTimer = setTimeout(() => setShowSplash(false), SPLASH_DURATION_MS + 500)
    return () => {
      clearTimeout(leaveTimer)
      clearTimeout(removeTimer)
    }
  }, [])

  return (
    <>
      {/* Overlays the app rather than gating its mount - the splash is a purely
          cosmetic flourish, so routes (and the auth check they depend on) start
          loading immediately instead of being delayed behind it. */}
      {showSplash && <SplashScreen leaving={splashLeaving} />}
      <BrowserRouter>
        <ToastProvider>
          <AuthProvider>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route element={<ProtectedRoute />}>
                <Route element={<Layout />}>
                  <Route path="/" element={<Navigate to="/jobs" replace />} />
                  <Route path="/jobs" element={<Jobs />} />
                  <Route path="/jobs/:jobId" element={<JobDetail />} />
                  <Route path="/criteria" element={<Criteria />} />
                  <Route path="/criteria/new" element={<CriteriaForm />} />
                  <Route path="/criteria/:id" element={<CriteriaDetail />} />
                  <Route path="/criteria/:id/edit" element={<CriteriaForm />} />
                  <Route path="/candidates" element={<Candidates />} />
                  <Route path="/candidates/:candidateId" element={<CandidateDetail />} />
                  <Route path="/compare" element={<Compare />} />
                  <Route path="/settings" element={<Settings />} />
                </Route>
              </Route>
            </Routes>
          </AuthProvider>
        </ToastProvider>
      </BrowserRouter>
    </>
  )
}

export default App
