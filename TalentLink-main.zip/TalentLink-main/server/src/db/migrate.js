import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'
import bcrypt from 'bcryptjs'
import 'dotenv/config'
import db from '../services/db.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

export function runMigrations() {
  rebuildRedesignedTables()

  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf-8')
  db.exec(schema)
  ensureColumn('users', 'phone', 'TEXT')
  ensureColumn('users', 'job_title', 'TEXT')
  ensureColumn('users', 'department', 'TEXT')
  ensureColumn('users', 'bio', 'TEXT')
  ensureColumn('users', 'profile_image', 'TEXT')
  ensureColumn('users', 'role', "TEXT DEFAULT 'recruiter'")
  ensureColumn('users', 'preferences', 'TEXT')
  ensureColumn('users', 'last_login_at', 'TEXT')
  seedRecruiter()
  seedAdmin()
  seedCriteriaTemplates()
}

// One-time structural migration for the Job Description / Criteria Template
// redesign: skills/education/experience moved off jobs and onto
// criteria_templates, and candidate_evaluations gained a weighted
// department/company breakdown. SQLite can't ALTER these column sets in
// place, so each table is checked independently for its own old-shape marker
// and rebuilt only if needed - this stays correct even if the tables are
// migrated across separate runs (e.g. one table rebuilt, process interrupted,
// migrate run again later). This drops the affected table's existing rows -
// users, candidates, and resumes are untouched - and seedCriteriaTemplates()
// below repopulates a starter template so the app isn't empty afterward.
function hasColumn(table, column) {
  return db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === column)
}

function tableExists(table) {
  return Boolean(db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?").get(table))
}

function rebuildRedesignedTables() {
  const jobsIsOldShape = tableExists('jobs') && hasColumn('jobs', 'required_skills')
  const criteriaIsOldShape = tableExists('criteria_templates') && hasColumn('criteria_templates', 'evaluation_weights')
  const evaluationsIsOldShape =
    tableExists('candidate_evaluations') && hasColumn('candidate_evaluations', 'skills_score')

  if (!jobsIsOldShape && !criteriaIsOldShape && !evaluationsIsOldShape) return

  // candidate_evaluations references both jobs and criteria_templates, so a
  // rebuild of either one invalidates its rows too.
  if (jobsIsOldShape || criteriaIsOldShape || evaluationsIsOldShape) {
    db.exec('DROP TABLE IF EXISTS candidate_evaluations')
  }
  if (jobsIsOldShape) db.exec('DROP TABLE IF EXISTS jobs')
  if (criteriaIsOldShape) db.exec('DROP TABLE IF EXISTS criteria_templates')
  console.log('Rebuilt jobs/criteria_templates/candidate_evaluations for the new schema (old rows were reset).')
}

// Lightweight, additive schema evolution for columns added after initial release -
// SQLite's ALTER TABLE has no "ADD COLUMN IF NOT EXISTS", so check first.
function ensureColumn(table, column, definition) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all()
  if (!columns.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`)
  }
}

function seedRecruiter() {
  const email = process.env.SEED_RECRUITER_EMAIL || 'recruiter@talentlink.dev'
  const password = process.env.SEED_RECRUITER_PASSWORD || 'recruiter123'
  const name = process.env.SEED_RECRUITER_NAME || 'Demo Recruiter'

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email)
  if (existing) return

  const passwordHash = bcrypt.hashSync(password, 10)
  db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)').run(
    name,
    email,
    passwordHash,
  )
  console.log(`Seeded recruiter account: ${email}`)
}

// Department/admin account used to manage the criteria library - kept separate
// from the recruiter persona since only admins can create/edit/delete templates.
function seedAdmin() {
  const email = process.env.SEED_ADMIN_EMAIL || 'admin@talentlink.dev'
  const password = process.env.SEED_ADMIN_PASSWORD || 'admin123'
  const name = process.env.SEED_ADMIN_NAME || 'Demo Admin'

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email)
  if (existing) return

  const passwordHash = bcrypt.hashSync(password, 10)
  db.prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)').run(
    name,
    email,
    passwordHash,
    'admin',
  )
  console.log(`Seeded admin account: ${email}`)
}

// Seeds one starter template per department admin so the Criteria Library and
// the job-creation picker aren't empty on a fresh (or just-rebuilt) DB.
function seedCriteriaTemplates() {
  const existing = db.prepare('SELECT COUNT(*) as count FROM criteria_templates').get().count
  if (existing > 0) return

  const admin = db.prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1").get()

  db.prepare(
    `INSERT INTO criteria_templates
      (department, role_title, description, education_requirements, minimum_experience_years,
       certifications, required_skills, preferred_skills, competencies, portfolio_requirements,
       evaluation_rules, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'Computer Science',
    'Software Engineer',
    "The department's baseline professional standard for software engineering hires, independent of any single job posting.",
    JSON.stringify(["Bachelor's in Computer Science or related field"]),
    2,
    JSON.stringify([]),
    JSON.stringify(['JavaScript', 'React', 'Node.js', 'SQL']),
    JSON.stringify(['TypeScript', 'Docker', 'AWS']),
    JSON.stringify(['Communication', 'Problem solving', 'Teamwork']),
    JSON.stringify(['At least one substantial project demonstrating end-to-end ownership']),
    JSON.stringify({
      technical_skills: {
        weight: 45,
        method:
          'Compare required skills against the extracted resume skills. Preferred skills increase the score but do not penalize missing candidates.',
      },
      experience: {
        weight: 25,
        method: 'Compare candidate years of experience with the minimum required experience.',
      },
      education: {
        weight: 15,
        method: "Compare the candidate's degree and field of study with the required education.",
      },
      portfolio: {
        weight: 10,
        method: 'Evaluate project relevance and complexity.',
      },
      competencies: {
        weight: 5,
        method: 'Infer competencies only when supported by resume evidence.',
      },
    }),
    admin?.id ?? null,
  )
  console.log('Seeded starter criteria template: Computer Science -> Software Engineer')
}

if (process.argv[1]?.endsWith('migrate.js')) {
  runMigrations()
  console.log('Migration complete.')
}
