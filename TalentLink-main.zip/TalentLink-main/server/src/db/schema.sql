CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS criteria_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  department TEXT NOT NULL,
  role_title TEXT NOT NULL,
  description TEXT,
  education_requirements TEXT,
  minimum_experience_years REAL,
  certifications TEXT,
  min_age INTEGER,
  max_age INTEGER,
  required_skills TEXT,
  preferred_skills TEXT,
  competencies TEXT,
  portfolio_requirements TEXT,
  evaluation_rules TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_criteria_department ON criteria_templates(department);

CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  department TEXT,
  employment_type TEXT,
  location TEXT,
  salary_min REAL,
  salary_max REAL,
  status TEXT DEFAULT 'open',
  about_role TEXT,
  responsibilities TEXT,
  company_info TEXT,
  team_info TEXT,
  benefits TEXT,
  criteria_template_id INTEGER REFERENCES criteria_templates(id),
  created_by INTEGER REFERENCES users(id),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS resumes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  original_filename TEXT NOT NULL,
  stored_path TEXT NOT NULL,
  file_type TEXT,
  raw_text TEXT,
  parse_status TEXT DEFAULT 'pending',
  error_message TEXT,
  uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  resume_id INTEGER REFERENCES resumes(id),
  name TEXT,
  email TEXT,
  phone TEXT,
  age INTEGER,
  education TEXT,
  skills TEXT,
  programming_languages TEXT,
  experience TEXT,
  total_experience_years REAL,
  certifications TEXT,
  projects TEXT,
  missing_fields TEXT,
  extracted_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_candidates_resume ON candidates(resume_id);

CREATE TABLE IF NOT EXISTS candidate_evaluations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  candidate_id INTEGER REFERENCES candidates(id),
  job_id INTEGER REFERENCES jobs(id),
  criteria_template_id INTEGER REFERENCES criteria_templates(id),
  overall_score REAL,
  overall_explanation TEXT,
  department_score REAL,
  department_breakdown TEXT,
  company_score REAL,
  company_explanation TEXT,
  company_matches TEXT,
  company_gaps TEXT,
  missing_requirements TEXT,
  evaluated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(candidate_id, job_id)
);

CREATE INDEX IF NOT EXISTS idx_evaluations_job ON candidate_evaluations(job_id);
CREATE INDEX IF NOT EXISTS idx_evaluations_candidate ON candidate_evaluations(candidate_id);
