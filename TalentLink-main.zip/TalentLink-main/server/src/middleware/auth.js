import jwt from 'jsonwebtoken'
import db from '../services/db.js'
import { ApiError } from './errorHandler.js'

export const COOKIE_NAME = 'talentlink_token'

export function requireAuth(req, res, next) {
  const token = req.cookies?.[COOKIE_NAME]
  if (!token) return next(new ApiError(401, 'Not authenticated', 'UNAUTHENTICATED'))

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET)
    next()
  } catch {
    next(new ApiError(401, 'Invalid or expired session', 'UNAUTHENTICATED'))
  }
}

// Looks the role up fresh on every request instead of trusting the JWT (which
// only carries id/name/email) - a role change or revocation takes effect
// immediately rather than waiting for the token to expire.
export function requireRole(...roles) {
  return (req, res, next) => {
    const user = db.prepare('SELECT role FROM users WHERE id = ?').get(req.user.id)
    if (!user || !roles.includes(user.role)) {
      return next(new ApiError(403, 'You do not have permission to perform this action', 'FORBIDDEN'))
    }
    next()
  }
}
