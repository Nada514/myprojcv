import multer from 'multer'
import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'
import { v4 as uuidv4 } from 'uuid'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
// Deliberately separate from the resumes uploads dir - avatars are served
// publicly (like any profile picture); resumes hold candidate PII and must
// never be reachable via a static file route.
export const avatarsDir = path.resolve(__dirname, '../../uploads/avatars')
if (!fs.existsSync(avatarsDir)) fs.mkdirSync(avatarsDir, { recursive: true })

const allowedExtensions = new Set(['.jpg', '.jpeg', '.png', '.webp'])

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, avatarsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase()
    cb(null, `${uuidv4()}${ext}`)
  },
})

function fileFilter(req, file, cb) {
  const ext = path.extname(file.originalname).toLowerCase()
  if (!allowedExtensions.has(ext)) {
    cb(new Error('Only JPG, PNG, and WEBP images are supported'))
    return
  }
  cb(null, true)
}

export const uploadAvatarFile = multer({
  storage,
  fileFilter,
  limits: { fileSize: 3 * 1024 * 1024 },
}).single('avatar')
