import { Router } from 'express'
import { requireAuth } from '../middleware/auth.js'
import { uploadResumeFiles } from '../middleware/upload.js'
import { uploadResumes, listResumes, getResume, retryExtraction } from '../controllers/resumesController.js'
import { ApiError } from '../middleware/errorHandler.js'

const router = Router()

router.use(requireAuth)

function handleUpload(req, res, next) {
  uploadResumeFiles(req, res, (err) => {
    if (err) return next(new ApiError(400, err.message, 'UPLOAD_ERROR'))
    next()
  })
}

router.get('/', listResumes)
router.get('/:id', getResume)
router.post('/upload', handleUpload, uploadResumes)
router.post('/:id/retry', retryExtraction)

export default router
