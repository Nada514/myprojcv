import { Router } from 'express'
import { requireAuth } from '../middleware/auth.js'
import { listJobs, getJob, createJob, updateJob, deleteJob } from '../controllers/jobsController.js'
import { runMatch, listEvaluationsForJob, getEvaluation } from '../controllers/evaluationsController.js'

const router = Router()

router.use(requireAuth)

router.get('/', listJobs)
router.post('/', createJob)
router.get('/:id', getJob)
router.put('/:id', updateJob)
router.delete('/:id', deleteJob)

router.post('/:jobId/match', runMatch)
router.get('/:jobId/evaluations', listEvaluationsForJob)
router.get('/:jobId/candidates/:candidateId/evaluation', getEvaluation)

export default router
