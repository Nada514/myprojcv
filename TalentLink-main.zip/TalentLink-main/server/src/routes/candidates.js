import { Router } from 'express'
import { requireAuth } from '../middleware/auth.js'
import { listCandidates, getCandidate, deleteCandidate } from '../controllers/candidatesController.js'

const router = Router()

router.use(requireAuth)

router.get('/', listCandidates)
router.get('/:id', getCandidate)
router.delete('/:id', deleteCandidate)

export default router
