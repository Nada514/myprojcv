import { Router } from 'express'
import { requireAuth, requireRole } from '../middleware/auth.js'
import {
  listCriteria,
  getCriteria,
  createCriteria,
  updateCriteria,
  deleteCriteria,
} from '../controllers/criteriaController.js'

const router = Router()

router.use(requireAuth)

router.get('/', listCriteria)
router.get('/:id', getCriteria)
router.post('/', requireRole('admin'), createCriteria)
router.put('/:id', requireRole('admin'), updateCriteria)
router.delete('/:id', requireRole('admin'), deleteCriteria)

export default router
