import { Router } from 'express'
import {
  register,
  login,
  logout,
  me,
  getProfile,
  updateProfile,
  updatePreferences,
  changePassword,
  uploadAvatar,
  deleteAccount,
} from '../controllers/authController.js'
import { requireAuth } from '../middleware/auth.js'
import { uploadAvatarFile } from '../middleware/uploadAvatar.js'
import { ApiError } from '../middleware/errorHandler.js'

const router = Router()

function handleAvatarUpload(req, res, next) {
  uploadAvatarFile(req, res, (err) => {
    if (err) return next(new ApiError(400, err.message, 'UPLOAD_ERROR'))
    next()
  })
}

router.post('/register', register)
router.post('/login', login)
router.post('/logout', logout)
router.get('/me', requireAuth, me)

router.get('/profile', requireAuth, getProfile)
router.put('/profile', requireAuth, updateProfile)
router.post('/profile/avatar', requireAuth, handleAvatarUpload, uploadAvatar)
router.put('/preferences', requireAuth, updatePreferences)
router.put('/change-password', requireAuth, changePassword)
router.delete('/account', requireAuth, deleteAccount)

export default router
