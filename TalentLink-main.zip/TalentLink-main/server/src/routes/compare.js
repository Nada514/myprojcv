import { Router } from 'express'
import { requireAuth } from '../middleware/auth.js'
import { compareCandidates } from '../controllers/compareController.js'

const router = Router()

router.use(requireAuth)
router.post('/', compareCandidates)

export default router
