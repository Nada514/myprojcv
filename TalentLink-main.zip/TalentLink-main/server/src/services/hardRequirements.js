// Objective, non-AI checks for requirements that should be reliable and cheap
// (age/experience thresholds) rather than left to model judgment. These
// thresholds live on the criteria template (the department's standard), not
// the job posting. Only flags a gap when both the requirement and the
// candidate value are known - unknown candidate data is surfaced separately
// via missing_fields, never treated as an automatic fail here.
export function checkHardRequirements(criteriaTemplate, candidate) {
  const unmet = []
  if (!criteriaTemplate) return unmet

  if (criteriaTemplate.min_age != null && candidate.age != null && candidate.age < criteriaTemplate.min_age) {
    unmet.push(`Below minimum age of ${criteriaTemplate.min_age} (candidate is ${candidate.age})`)
  }
  if (criteriaTemplate.max_age != null && candidate.age != null && candidate.age > criteriaTemplate.max_age) {
    unmet.push(`Above maximum age of ${criteriaTemplate.max_age} (candidate is ${candidate.age})`)
  }
  if (
    criteriaTemplate.minimum_experience_years != null &&
    candidate.total_experience_years != null &&
    candidate.total_experience_years < criteriaTemplate.minimum_experience_years
  ) {
    unmet.push(
      `Requires at least ${criteriaTemplate.minimum_experience_years} years of experience (candidate has ${candidate.total_experience_years})`,
    )
  }

  return unmet
}
