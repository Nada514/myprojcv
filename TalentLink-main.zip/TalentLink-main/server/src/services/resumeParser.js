import fs from 'node:fs/promises'
import { PDFParse } from 'pdf-parse'
import mammoth from 'mammoth'

export async function extractRawText(filePath, fileType) {
  const buffer = await fs.readFile(filePath)

  if (fileType === 'pdf') {
    const parser = new PDFParse({ data: buffer })
    const result = await parser.getText()
    await parser.destroy()
    return result.text.trim()
  }

  if (fileType === 'docx') {
    const result = await mammoth.extractRawText({ buffer })
    return result.value.trim()
  }

  throw new Error(`Unsupported file type: ${fileType}`)
}
