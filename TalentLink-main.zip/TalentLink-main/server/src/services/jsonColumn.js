export function toJson(value) {
  if (value === undefined || value === null) return null
  return JSON.stringify(value)
}

export function fromJson(value, fallback = []) {
  if (!value) return fallback
  try {
    return JSON.parse(value)
  } catch {
    return fallback
  }
}
