import * as claudeProvider from './claudeProvider.js'
import * as litellmProvider from './litellmProvider.js'

// Add new providers here (e.g. openai: openaiProvider) to support switching
// via the AI_PROVIDER env var without touching any calling code.
const providers = {
  claude: claudeProvider,
  litellm: litellmProvider,
}

export function getProvider() {
  const name = process.env.AI_PROVIDER || 'claude'
  const provider = providers[name]
  if (!provider) throw new Error(`Unknown AI provider: "${name}"`)
  return provider
}

// Logged once at server startup (see app.js) so "which provider/model/key is
// actually active" is never a guessing game - never logs the key itself,
// only whether it's present and whether its shape looks right.
export function logStartupConfig() {
  const providerName = process.env.AI_PROVIDER || 'claude (default - AI_PROVIDER not set)'
  console.log(`[STARTUP] AI_PROVIDER = "${providerName}"`)

  if ((process.env.AI_PROVIDER || 'claude') === 'claude') {
    const key = process.env.ANTHROPIC_API_KEY
    console.log(`[STARTUP] ANTHROPIC_API_KEY present: ${Boolean(key)}`)
    console.log(`[STARTUP] ANTHROPIC_MODEL = "${process.env.ANTHROPIC_MODEL || '(unset - provider will pick a default)'}"`)
    if (key && !key.startsWith('sk-ant-')) {
      console.warn(
        '[STARTUP] WARNING: ANTHROPIC_API_KEY does not start with "sk-ant-" - this does not look like a real ' +
          'Anthropic API key (get one from https://console.anthropic.com/settings/keys). If this is a key for ' +
          'a proxy (e.g. LiteLLM), set AI_PROVIDER accordingly instead of "claude".',
      )
    }
  } else if (process.env.AI_PROVIDER === 'litellm') {
    console.log(`[STARTUP] LITELLM_API_KEY present: ${Boolean(process.env.LITELLM_API_KEY)}`)
    console.log(`[STARTUP] LITELLM_MODEL = "${process.env.LITELLM_MODEL || '(unset - provider will pick a default)'}"`)
    console.log(`[STARTUP] LITELLM_BASE_URL = "${process.env.LITELLM_BASE_URL || '(unset - provider will pick a default)'}"`)
  }
}
