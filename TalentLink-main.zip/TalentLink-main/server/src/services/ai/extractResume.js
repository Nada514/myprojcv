import { getProvider } from './aiProvider.js'

const extractionTool = {
  name: 'record_candidate_profile',
  description: 'Record structured candidate information extracted from a resume.',
  input_schema: {
    type: 'object',
    properties: {
      name: { type: ['string', 'null'] },
      email: { type: ['string', 'null'] },
      phone: { type: ['string', 'null'] },
      age: { type: ['integer', 'null'], description: 'Only if explicitly stated in the resume.' },
      education: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            degree: { type: 'string' },
            university: { type: 'string' },
            year: { type: ['string', 'null'] },
          },
          required: ['degree', 'university'],
        },
      },
      skills: { type: 'array', items: { type: 'string' } },
      programming_languages: { type: 'array', items: { type: 'string' } },
      experience: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            company: { type: 'string' },
            start: { type: ['string', 'null'] },
            end: { type: ['string', 'null'] },
            description: { type: ['string', 'null'] },
          },
          required: ['title', 'company'],
        },
      },
      total_experience_years: {
        type: ['number', 'null'],
        description: 'Best estimate from summed experience entries; null if it cannot be determined.',
      },
      certifications: { type: 'array', items: { type: 'string' } },
      projects: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            description: { type: ['string', 'null'] },
          },
          required: ['name'],
        },
      },
      missing_fields: {
        type: 'array',
        items: { type: 'string' },
        description:
          'Expected fields that could not be found in the resume text, e.g. "phone", "graduation_year", "experience_dates".',
      },
    },
    required: [
      'education',
      'skills',
      'programming_languages',
      'experience',
      'certifications',
      'projects',
      'missing_fields',
    ],
  },
}

const SYSTEM_PROMPT = `You are an assistant that extracts structured information from resumes for a recruiter.

Rules:
- Only extract information explicitly present in the resume text. Never invent, guess, or infer missing data.
- If a scalar field is not present, set it to null. If a list field has no entries, use an empty array.
- List every expected field you could NOT find in "missing_fields" (use keys like "email", "phone", "age", "graduation_year", "experience_dates").
- Only fill "age" if it is explicitly stated or a birth date is given; do not estimate it from graduation years or experience length.
- Keep skills and programming languages as separate lists: "programming_languages" is for languages like Python, Java, C++; "skills" is for everything else (frameworks, tools, soft skills, domains).`

export async function extractCandidateFromResume(rawText) {
  const provider = getProvider()
  const prompt = `Extract candidate information from the resume text below and call the record_candidate_profile tool with the result.\n\n---RESUME TEXT---\n${rawText}`

  return provider.completeStructured({
    system: SYSTEM_PROMPT,
    prompt,
    tool: extractionTool,
  })
}
