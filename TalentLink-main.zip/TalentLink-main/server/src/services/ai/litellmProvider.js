// Routes through the iHQ LiteLLM proxy (https://litellm.i-hq.tech), which only
// speaks the OpenAI-compatible /v1/chat/completions API - not Anthropic's
// native Messages API - even though the underlying model is a Claude model
// (e.g. "anthropic/claude-haiku-4-5"). Kept as a separate provider file per
// the aiProvider.js abstraction rather than bending claudeProvider.js's
// Anthropic-SDK client to a protocol it doesn't speak.

class MissingApiKeyError extends Error {}

function getConfig() {
  if (!process.env.LITELLM_API_KEY) {
    throw new MissingApiKeyError(
      'AI service authentication failed: LITELLM_API_KEY is not set - add your team key to server/.env and restart the server.',
    )
  }
  return {
    apiKey: process.env.LITELLM_API_KEY,
    baseURL: process.env.LITELLM_BASE_URL || 'https://litellm.i-hq.tech/v1',
    model: process.env.LITELLM_MODEL || 'anthropic/claude-haiku-4-5',
  }
}

// Anthropic-style { name, description, input_schema } -> OpenAI function-calling shape.
function toOpenAiTool(tool) {
  return {
    type: 'function',
    function: {
      name: tool.name,
      description: tool.description,
      parameters: tool.input_schema,
    },
  }
}

function cleanAiError(err) {
  const status = err.status
  if (status === 401 || status === 403) {
    return new Error(
      `AI service authentication failed: ${err.apiMessage || 'the API rejected the request'} - the LITELLM_API_KEY in server/.env is missing, invalid, or expired. Check litellm-api-keys.xlsx and update server/.env, then restart the server.`,
    )
  }
  if (status === 429) {
    return new Error('AI service rate limit reached (or budget exhausted) - please try again in a moment')
  }
  if (status >= 500) {
    return new Error('AI service is temporarily unavailable - please try again shortly')
  }
  return new Error(err.apiMessage ? `AI service error: ${err.apiMessage}` : 'AI service request failed')
}

function isRetryable(err) {
  if (err instanceof MissingApiKeyError) return false
  const status = err.status
  if (!status) return true
  return status === 429 || status >= 500
}

async function callOnce({ system, prompt, tool }) {
  const { apiKey, baseURL, model } = getConfig()
  const openAiTool = toOpenAiTool(tool)

  const response = await fetch(`${baseURL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: prompt },
      ],
      tools: [openAiTool],
      tool_choice: { type: 'function', function: { name: tool.name } },
    }),
  })

  if (!response.ok) {
    const body = await response.json().catch(() => null)
    const err = new Error(body?.error?.message || `LiteLLM request failed with status ${response.status}`)
    err.status = response.status
    err.apiMessage = body?.error?.message
    throw err
  }

  const data = await response.json()
  const toolCall = data.choices?.[0]?.message?.tool_calls?.[0]
  if (!toolCall) {
    throw new Error('AI response did not include the expected structured output')
  }
  return JSON.parse(toolCall.function.arguments)
}

export async function completeStructured(args) {
  try {
    return await callOnce(args)
  } catch (err) {
    if (!isRetryable(err)) {
      console.error('AI request failed (not retrying):', err)
      throw cleanAiError(err)
    }
    try {
      return await callOnce(args)
    } catch (retryErr) {
      console.error('AI request failed after retry:', retryErr)
      throw cleanAiError(retryErr)
    }
  }
}
