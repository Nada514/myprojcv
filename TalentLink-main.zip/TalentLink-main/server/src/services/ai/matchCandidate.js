import { getProvider } from './aiProvider.js'

// Every category the department's evaluation_rules can weight. Fixed set so
// the tool schema and the deterministic scoring in evaluationsController.js
// can rely on all five always being present.
const CATEGORIES = ['technical_skills', 'experience', 'education', 'portfolio', 'competencies']

function categoryProperty(description) {
  return {
    type: 'object',
    properties: {
      score: { type: 'number', description: '0-100 score for this category, judged only against the criteria template.' },
      evidence_found: {
        type: 'array',
        items: { type: 'string' },
        description: 'Specific, concrete evidence from the resume that supports this score.',
      },
      missing: {
        type: 'array',
        items: { type: 'string' },
        description: 'Specific things the template asks for in this category that the candidate does not show.',
      },
      reason: { type: 'string', description: 'One or two sentences explaining the score.' },
    },
    required: ['score', 'evidence_found', 'missing', 'reason'],
    description,
  }
}

const matchTool = {
  name: 'record_candidate_match',
  description: 'Record a candidate evaluation against both the department criteria template and the company job posting.',
  input_schema: {
    type: 'object',
    properties: {
      technical_skills: categoryProperty(
        "Score against the template's required_skills/preferred_skills only.",
      ),
      experience: categoryProperty(
        "Score against the template's minimum_experience_years only.",
      ),
      education: categoryProperty(
        "Score against the template's education_requirements only.",
      ),
      portfolio: categoryProperty(
        "Score the relevance and complexity of the candidate's projects against the template's portfolio_requirements.",
      ),
      competencies: categoryProperty(
        "Score against the template's competencies list - only infer a competency when the resume gives concrete supporting evidence (e.g. leading a project for 'Leadership'), never assume it.",
      ),
      company_score: {
        type: 'number',
        description:
          "0-100 score for how well the candidate matches THIS JOB POSTING's own fields (about_role, responsibilities, employment_type, location) - independent of the criteria template, even where they overlap.",
      },
      company_matches: {
        type: 'array',
        items: { type: 'string' },
        description: "Specific ways the candidate fits this job posting's own stated responsibilities/context.",
      },
      company_gaps: {
        type: 'array',
        items: { type: 'string' },
        description: "Specific ways the candidate falls short of this job posting's own stated responsibilities/context.",
      },
      company_explanation: {
        type: 'string',
        description: 'Short paragraph explaining company_score in plain language.',
      },
      overall_explanation: {
        type: 'string',
        description:
          'Short paragraph synthesizing the department and company results into one plain-language explanation of overall fit.',
      },
    },
    required: [
      ...CATEGORIES,
      'company_score',
      'company_matches',
      'company_gaps',
      'company_explanation',
      'overall_explanation',
    ],
  },
}

const SYSTEM_PROMPT = `You are an assistant that helps a recruiter evaluate a candidate against TWO independent sources. You never make the hiring decision - you only score and explain.

The two sources must never be blended:
- The CRITERIA TEMPLATE is the university department's objective professional competency standard for this role in general, set independent of any single job posting. Score technical_skills, experience, education, portfolio, and competencies purely against it.
- The JOB POSTING is this specific company's own stated context for this one posting (about_role, responsibilities, employment_type, location). Score company_score/company_matches/company_gaps purely against it.

Rules:
- Match SEMANTICALLY, not just by exact keyword. For example "React" satisfies a "Frontend Development" requirement, "PyTorch" or "TensorFlow" satisfies a "Machine Learning" requirement, "Node.js" satisfies "Backend Development", etc. Use your judgment about closely related or subsumed skills.
- Every score must be justified with specific, concrete evidence tied to the candidate's actual background (e.g. "3 years of React experience" not "good skills"). Never return a score without it.
- Do not penalize the candidate for information that is simply missing from their profile unless it directly maps to something the template or job posting actually asks for.
- Do not invent candidate experience, skills, or projects that aren't listed in their profile.
- For "competencies" specifically: only claim a competency is demonstrated when the resume gives concrete supporting evidence (a specific project, role, or outcome) - do not infer soft skills from job titles alone.
- Populate every field for every category, even when the score is low - explain why.`

export async function matchCandidateToJob(candidateProfile, jobPosting, criteriaTemplate) {
  const provider = getProvider()
  const prompt = `Evaluate this candidate against the criteria template and the job posting, then call record_candidate_match with your assessment.

---CRITERIA TEMPLATE (JSON) - department's professional standard---
${JSON.stringify(criteriaTemplate, null, 2)}

---JOB POSTING (JSON) - this company's specific posting---
${JSON.stringify(jobPosting, null, 2)}

---CANDIDATE PROFILE (JSON)---
${JSON.stringify(candidateProfile, null, 2)}`

  return provider.completeStructured({
    system: SYSTEM_PROMPT,
    prompt,
    tool: matchTool,
  })
}
