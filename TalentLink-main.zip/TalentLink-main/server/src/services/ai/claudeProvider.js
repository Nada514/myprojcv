import Anthropic from '@anthropic-ai/sdk'

let client = null

class MissingApiKeyError extends Error {}
class InvalidKeyFormatError extends Error {}

// Real Anthropic keys (from https://console.anthropic.com/settings/keys) always
// start with "sk-ant-". Keys from other systems (LiteLLM proxies, OpenAI, etc.)
// have a different shape and will always fail Anthropic's auth with a generic
// 401 "invalid x-api-key" - this check turns that into an immediate, specific,
// actionable error instead of a network round trip to find out the same thing.
function assertKeyLooksValid(key) {
  if (!key.startsWith('sk-ant-')) {
    throw new InvalidKeyFormatError(
      `ANTHROPIC_API_KEY does not look like a real Anthropic API key (expected it to start with "sk-ant-"). ` +
        `This value looks like it may be from a different system (e.g. a LiteLLM/proxy key). Get a real key from ` +
        `https://console.anthropic.com/settings/keys and set ANTHROPIC_API_KEY in server/.env, then restart the server.`,
    )
  }
}

function getClient() {
  if (!client) {
    const key = process.env.ANTHROPIC_API_KEY
    if (!key) {
      throw new MissingApiKeyError(
        'AI service authentication failed: ANTHROPIC_API_KEY is not set - add a valid key to server/.env (get one from https://console.anthropic.com/settings/keys) and restart the server.',
      )
    }
    assertKeyLooksValid(key)
    client = new Anthropic({ apiKey: key })
  }
  return client
}

// Anthropic SDK errors carry a status + nested error.error.message plus a raw
// request ID that's meaningless to a recruiter. Turn them into one clean
// sentence that still includes the API's own message and request ID, and
// keep the full error server-side (console.error) for debugging.
function cleanAiError(err) {
  const status = err?.status
  const apiMessage = err?.error?.error?.message
  const apiType = err?.error?.error?.type
  const requestId = err?.requestID || err?.request_id

  if (err instanceof MissingApiKeyError || err instanceof InvalidKeyFormatError) return err
  if (!status) return err instanceof Error ? err : new Error('Could not reach the AI service')

  const suffix = requestId ? ` (request_id: ${requestId})` : ''

  if (status === 401 || status === 403) {
    return new Error(
      `AI service authentication failed: ${apiMessage || 'the API rejected the request'} - the ANTHROPIC_API_KEY in server/.env is missing, invalid, or expired. Get a valid key from https://console.anthropic.com/settings/keys and update server/.env, then restart the server.${suffix}`,
    )
  }
  if (status === 404 && apiType === 'not_found_error') {
    return new Error(
      `AI service error: model "${process.env.ANTHROPIC_MODEL || '(default)'}" was not found or is unsupported. Check ANTHROPIC_MODEL in server/.env against the current model list.${suffix}`,
    )
  }
  if (status === 429) {
    return new Error(`AI service rate limit reached - please try again in a moment${suffix}`)
  }
  if (status === 400) {
    return new Error(`AI service rejected the request: ${apiMessage || 'malformed request'}${suffix}`)
  }
  if (status >= 500) {
    return new Error(`AI service is temporarily unavailable - please try again shortly${suffix}`)
  }
  return new Error(apiMessage ? `AI service error: ${apiMessage}${suffix}` : `AI service request failed${suffix}`)
}

function isRetryable(err) {
  if (err instanceof MissingApiKeyError || err instanceof InvalidKeyFormatError) return false
  const status = err?.status
  if (!status) return true
  return status === 429 || status >= 500
}

async function callOnce({ system, prompt, tool }) {
  const model = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5'
  console.log(
    `[CLAUDE] completeStructured called - tool="${tool.name}" model="${model}" endpoint="https://api.anthropic.com/v1/messages" promptLength=${prompt.length}`,
  )

  const response = await getClient().messages.create({
    model,
    max_tokens: 4096,
    system,
    messages: [{ role: 'user', content: prompt }],
    tools: [tool],
    tool_choice: { type: 'tool', name: tool.name },
  })

  console.log(
    `[CLAUDE] response received - stop_reason="${response.stop_reason}" model="${response.model}" usage=${JSON.stringify(response.usage)}`,
  )

  const toolUse = response.content.find((block) => block.type === 'tool_use')
  if (!toolUse) {
    console.error('[CLAUDE] response did not contain a tool_use block. Full content:', JSON.stringify(response.content))
    throw new Error('AI response did not include the expected structured output')
  }
  return toolUse.input
}

export async function completeStructured(args) {
  try {
    return await callOnce(args)
  } catch (err) {
    console.error(
      `[CLAUDE] request failed - status=${err?.status} type=${err?.error?.error?.type} message=${err?.message}`,
    )
    console.error(err?.stack || err)
    if (!isRetryable(err)) {
      throw cleanAiError(err)
    }
    console.log('[CLAUDE] retrying once...')
    try {
      return await callOnce(args)
    } catch (retryErr) {
      console.error(
        `[CLAUDE] retry failed - status=${retryErr?.status} type=${retryErr?.error?.error?.type} message=${retryErr?.message}`,
      )
      console.error(retryErr?.stack || retryErr)
      throw cleanAiError(retryErr)
    }
  }
}
