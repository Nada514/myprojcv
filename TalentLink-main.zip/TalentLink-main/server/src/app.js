import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'
import dotenv from 'dotenv'
import express from 'express'
import cors from 'cors'
import cookieParser from 'cookie-parser'
import { runMigrations } from './db/migrate.js'
import { notFoundHandler, errorHandler } from './middleware/errorHandler.js'
import { avatarsDir } from './middleware/uploadAvatar.js'
import { logStartupConfig } from './services/ai/aiProvider.js'
import healthRouter from './routes/health.js'
import authRouter from './routes/auth.js'
import jobsRouter from './routes/jobs.js'
import resumesRouter from './routes/resumes.js'
import candidatesRouter from './routes/candidates.js'
import compareRouter from './routes/compare.js'
import dashboardRouter from './routes/dashboard.js'
import criteriaRouter from './routes/criteria.js'

// Load .env explicitly (rather than the side-effect-only 'dotenv/config') so
// we can log whether the file was actually found and parsed - "server not
// reading the updated .env" is a real, silent failure mode otherwise.
const __dirname = path.dirname(fileURLToPath(import.meta.url))
const envPath = path.resolve(__dirname, '../.env')
const dotenvResult = dotenv.config({ path: envPath })
console.log(
  `[STARTUP] .env ${fs.existsSync(envPath) ? 'found' : 'NOT FOUND'} at ${envPath} - dotenv.config() ${
    dotenvResult.error ? `FAILED: ${dotenvResult.error.message}` : `loaded ${Object.keys(dotenvResult.parsed || {}).length} vars`
  }`,
)

logStartupConfig()

runMigrations()

const app = express()

app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173', credentials: true }))
app.use(express.json())
app.use(cookieParser())
app.use('/avatars', express.static(avatarsDir))

app.use('/api/health', healthRouter)
app.use('/api/auth', authRouter)
app.use('/api/jobs', jobsRouter)
app.use('/api/resumes', resumesRouter)
app.use('/api/candidates', candidatesRouter)
app.use('/api/compare', compareRouter)
app.use('/api/dashboard', dashboardRouter)
app.use('/api/criteria', criteriaRouter)

app.use(notFoundHandler)
app.use(errorHandler)

const port = process.env.PORT || 4000
app.listen(port, () => {
  console.log(`TalentLink API listening on http://localhost:${port}`)
})
