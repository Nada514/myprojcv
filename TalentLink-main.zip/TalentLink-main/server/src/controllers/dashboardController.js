import db from '../services/db.js'

export function getSummary(req, res) {
  const resumeCount = db.prepare('SELECT COUNT(*) as count FROM resumes').get().count
  const jobCount = db.prepare('SELECT COUNT(*) as count FROM jobs').get().count
  const activeJobCount = db.prepare("SELECT COUNT(*) as count FROM jobs WHERE status = 'open'").get().count
  const candidateCount = db.prepare('SELECT COUNT(*) as count FROM candidates').get().count
  const evaluationCount = db.prepare('SELECT COUNT(*) as count FROM candidate_evaluations').get().count
  const averageMatchScore = db.prepare('SELECT AVG(overall_score) as avg FROM candidate_evaluations').get().avg

  const topCandidates = db
    .prepare(
      `SELECT c.id, c.name, c.email, ce.overall_score, j.title as job_title
       FROM candidate_evaluations ce
       JOIN candidates c ON c.id = ce.candidate_id
       JOIN jobs j ON j.id = ce.job_id
       ORDER BY ce.overall_score DESC
       LIMIT 5`,
    )
    .all()

  const recentResumes = db
    .prepare(
      `SELECT id, original_filename, parse_status, uploaded_at as timestamp
       FROM resumes ORDER BY uploaded_at DESC LIMIT 5`,
    )
    .all()
    .map((r) => ({
      type: 'resume_uploaded',
      message: `Resume uploaded: ${r.original_filename} (${r.parse_status})`,
      timestamp: r.timestamp,
    }))

  const recentJobs = db
    .prepare(`SELECT id, title, created_at as timestamp FROM jobs ORDER BY created_at DESC LIMIT 5`)
    .all()
    .map((j) => ({
      type: 'job_created',
      message: `Job created: ${j.title}`,
      timestamp: j.timestamp,
    }))

  const recentEvaluations = db
    .prepare(
      `SELECT ce.overall_score, c.name as candidate_name, j.title as job_title, ce.evaluated_at as timestamp
       FROM candidate_evaluations ce
       JOIN candidates c ON c.id = ce.candidate_id
       JOIN jobs j ON j.id = ce.job_id
       ORDER BY ce.evaluated_at DESC LIMIT 5`,
    )
    .all()
    .map((e) => ({
      type: 'match_run',
      message: `${e.candidate_name || 'A candidate'} scored ${Math.round(e.overall_score)}% against ${e.job_title}`,
      timestamp: e.timestamp,
    }))

  const recentActivity = [...recentResumes, ...recentJobs, ...recentEvaluations]
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 10)

  res.json({
    resumeCount,
    jobCount,
    activeJobCount,
    candidateCount,
    evaluationCount,
    averageMatchScore: averageMatchScore != null ? Math.round(averageMatchScore) : null,
    topCandidates,
    recentActivity,
  })
}
