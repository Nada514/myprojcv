import db from '../services/db.js'
import { fromJson } from '../services/jsonColumn.js'
import { ApiError } from '../middleware/errorHandler.js'

function serializeCandidate(row) {
  return {
    ...row,
    education: fromJson(row.education),
    skills: fromJson(row.skills),
    programming_languages: fromJson(row.programming_languages),
    experience: fromJson(row.experience),
    certifications: fromJson(row.certifications),
    projects: fromJson(row.projects),
    missing_fields: fromJson(row.missing_fields),
  }
}

export function compareCandidates(req, res, next) {
  const { candidateIds, jobId } = req.body || {}
  if (!Array.isArray(candidateIds) || candidateIds.length < 2) {
    return next(new ApiError(400, 'At least two candidateIds are required', 'VALIDATION_ERROR'))
  }

  const candidates = candidateIds.map((id) => {
    const row = db.prepare('SELECT * FROM candidates WHERE id = ?').get(id)
    if (!row) return null

    const candidate = serializeCandidate(row)

    const evaluation = jobId
      ? db
          .prepare('SELECT * FROM candidate_evaluations WHERE candidate_id = ? AND job_id = ?')
          .get(id, jobId)
      : db
          .prepare(
            'SELECT * FROM candidate_evaluations WHERE candidate_id = ? ORDER BY overall_score DESC LIMIT 1',
          )
          .get(id)

    return {
      ...candidate,
      evaluation: evaluation
        ? {
            ...evaluation,
            department_breakdown: fromJson(evaluation.department_breakdown),
            company_matches: fromJson(evaluation.company_matches),
            company_gaps: fromJson(evaluation.company_gaps),
            missing_requirements: fromJson(evaluation.missing_requirements),
          }
        : null,
    }
  })

  if (candidates.some((c) => c === null)) {
    return next(new ApiError(404, 'One or more candidates not found', 'NOT_FOUND'))
  }

  res.json({ candidates })
}
