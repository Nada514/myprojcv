import path from 'node:path'
import db from '../services/db.js'
import { extractRawText } from '../services/resumeParser.js'
import { extractCandidateFromResume } from '../services/ai/extractResume.js'
import { toJson } from '../services/jsonColumn.js'
import { ApiError } from '../middleware/errorHandler.js'

function fileTypeFromName(filename) {
  const ext = path.extname(filename).toLowerCase()
  if (ext === '.pdf') return 'pdf'
  if (ext === '.docx') return 'docx'
  return null
}

function serializeResume(row) {
  if (!row) return null
  const candidate = db.prepare('SELECT id FROM candidates WHERE resume_id = ?').get(row.id)
  return { ...row, candidate_id: candidate?.id ?? null }
}

export async function uploadResumes(req, res, next) {
  const files = req.files || []
  if (files.length === 0) {
    return next(new ApiError(400, 'At least one resume file is required', 'VALIDATION_ERROR'))
  }

  const results = []

  for (const file of files) {
    console.log(`[UPLOAD] Resume uploaded: ${file.originalname}`)
    const fileType = fileTypeFromName(file.originalname)
    const insert = db
      .prepare(
        `INSERT INTO resumes (original_filename, stored_path, file_type, parse_status)
         VALUES (?, ?, ?, 'pending')`,
      )
      .run(file.originalname, file.path, fileType)
    const resumeId = insert.lastInsertRowid

    try {
      console.log(`[PARSER] Extracting text from ${file.originalname} (${fileType})...`)
      const rawText = await extractRawText(file.path, fileType)
      db.prepare(
        `UPDATE resumes SET raw_text = ?, parse_status = 'parsed' WHERE id = ?`,
      ).run(rawText, resumeId)
      console.log(`[PARSER] Extracted ${rawText.length} characters from ${file.originalname}`)

      try {
        console.log(`[AI EXTRACTION] Sending resume ${resumeId} to Claude...`)
        await extractAndStoreCandidate(resumeId, rawText)
        console.log(`[CANDIDATE] Candidate created successfully for resume ${resumeId}`)
      } catch (aiErr) {
        // Text parsing succeeded but AI extraction failed (invalid/missing API key,
        // rate limit, malformed model response, etc). This is a terminal failure for
        // this upload, not a "still pending" state - record it as such so the resume
        // never silently masquerades as successful. No candidate row is created.
        console.error(`[ERROR] AI extraction failed for resume ${resumeId}:`, aiErr)
        db.prepare(`UPDATE resumes SET parse_status = 'ai_failed', error_message = ? WHERE id = ?`).run(
          aiErr.message,
          resumeId,
        )
      }
    } catch (err) {
      console.error(`[ERROR] Text extraction failed for resume ${resumeId}:`, err)
      db.prepare(
        `UPDATE resumes SET parse_status = 'failed', error_message = ? WHERE id = ?`,
      ).run(err.message, resumeId)
    }

    results.push(serializeResume(db.prepare('SELECT * FROM resumes WHERE id = ?').get(resumeId)))
  }

  res.status(201).json(results)
}

// Re-runs AI extraction for a resume whose text was already parsed but whose AI
// extraction previously failed - avoids forcing a full re-upload once the underlying
// issue (e.g. an invalid API key) is fixed.
export async function retryExtraction(req, res, next) {
  const resume = db.prepare('SELECT * FROM resumes WHERE id = ?').get(req.params.id)
  if (!resume) return next(new ApiError(404, 'Resume not found', 'NOT_FOUND'))
  if (!resume.raw_text) {
    return next(new ApiError(400, 'No extracted text to retry - re-upload the file', 'VALIDATION_ERROR'))
  }

  const existingCandidate = db.prepare('SELECT id FROM candidates WHERE resume_id = ?').get(resume.id)
  if (existingCandidate) {
    return res.json(serializeResume(resume))
  }

  try {
    console.log(`[AI EXTRACTION] Retrying resume ${resume.id}...`)
    await extractAndStoreCandidate(resume.id, resume.raw_text)
    db.prepare(`UPDATE resumes SET parse_status = 'parsed', error_message = NULL WHERE id = ?`).run(resume.id)
    console.log(`[CANDIDATE] Candidate created successfully for resume ${resume.id} (retry)`)
  } catch (aiErr) {
    console.error(`[ERROR] Retry AI extraction failed for resume ${resume.id}:`, aiErr)
    db.prepare(`UPDATE resumes SET parse_status = 'ai_failed', error_message = ? WHERE id = ?`).run(
      aiErr.message,
      resume.id,
    )
  }

  res.json(serializeResume(db.prepare('SELECT * FROM resumes WHERE id = ?').get(resume.id)))
}

async function extractAndStoreCandidate(resumeId, rawText) {
  const extracted = await extractCandidateFromResume(rawText)

  db.prepare(
    `INSERT INTO candidates
      (resume_id, name, email, phone, age, education, skills, programming_languages, experience,
       total_experience_years, certifications, projects, missing_fields)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    resumeId,
    extracted.name || null,
    extracted.email || null,
    extracted.phone || null,
    extracted.age ?? null,
    toJson(extracted.education || []),
    toJson(extracted.skills || []),
    toJson(extracted.programming_languages || []),
    toJson(extracted.experience || []),
    extracted.total_experience_years ?? null,
    toJson(extracted.certifications || []),
    toJson(extracted.projects || []),
    toJson(extracted.missing_fields || []),
  )
}

export function listResumes(req, res) {
  const rows = db.prepare('SELECT * FROM resumes ORDER BY uploaded_at DESC').all()
  res.json(rows.map(serializeResume))
}

export function getResume(req, res, next) {
  const row = db.prepare('SELECT * FROM resumes WHERE id = ?').get(req.params.id)
  if (!row) return next(new ApiError(404, 'Resume not found', 'NOT_FOUND'))
  res.json(serializeResume(row))
}
