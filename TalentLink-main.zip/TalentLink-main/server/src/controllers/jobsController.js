import db from '../services/db.js'
import { ApiError } from '../middleware/errorHandler.js'

const VALID_STATUSES = new Set(['open', 'closed', 'draft'])

function serializeJob(row) {
  if (!row) return null
  return { ...row }
}

export function listJobs(req, res) {
  const rows = db.prepare('SELECT * FROM jobs ORDER BY created_at DESC').all()
  res.json(rows.map(serializeJob))
}

export function getJob(req, res, next) {
  const row = db
    .prepare(
      `SELECT j.*, ct.department as criteria_department, ct.role_title as criteria_role_title
       FROM jobs j
       LEFT JOIN criteria_templates ct ON ct.id = j.criteria_template_id
       WHERE j.id = ?`,
    )
    .get(req.params.id)
  if (!row) return next(new ApiError(404, 'Job not found', 'NOT_FOUND'))
  res.json(serializeJob(row))
}

function readJobFields(body) {
  const {
    title,
    department,
    status,
    employment_type,
    location,
    salary_min,
    salary_max,
    about_role,
    responsibilities,
    company_info,
    team_info,
    benefits,
    criteria_template_id,
  } = body || {}
  return {
    title,
    department,
    status,
    employment_type,
    location,
    salary_min,
    salary_max,
    about_role,
    responsibilities,
    company_info,
    team_info,
    benefits,
    criteria_template_id,
  }
}

export function createJob(req, res, next) {
  const fields = readJobFields(req.body)

  if (!fields.title || !fields.title.trim()) {
    return next(new ApiError(400, 'Job title is required', 'VALIDATION_ERROR'))
  }
  if (!fields.criteria_template_id) {
    return next(
      new ApiError(400, 'A criteria template is required - select the department standard this job should be evaluated against', 'VALIDATION_ERROR'),
    )
  }

  const result = db
    .prepare(
      `INSERT INTO jobs
        (title, department, status, employment_type, location, salary_min, salary_max, about_role,
         responsibilities, company_info, team_info, benefits, criteria_template_id, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      fields.title.trim(),
      fields.department || null,
      VALID_STATUSES.has(fields.status) ? fields.status : 'open',
      fields.employment_type || null,
      fields.location || null,
      fields.salary_min ?? null,
      fields.salary_max ?? null,
      fields.about_role || null,
      fields.responsibilities || null,
      fields.company_info || null,
      fields.team_info || null,
      fields.benefits || null,
      fields.criteria_template_id,
      req.user.id,
    )

  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(result.lastInsertRowid)
  res.status(201).json(serializeJob(row))
}

export function updateJob(req, res, next) {
  const existing = db.prepare('SELECT * FROM jobs WHERE id = ?').get(req.params.id)
  if (!existing) return next(new ApiError(404, 'Job not found', 'NOT_FOUND'))

  const fields = readJobFields(req.body)

  if (!fields.title || !fields.title.trim()) {
    return next(new ApiError(400, 'Job title is required', 'VALIDATION_ERROR'))
  }
  if (!fields.criteria_template_id) {
    return next(
      new ApiError(400, 'A criteria template is required - select the department standard this job should be evaluated against', 'VALIDATION_ERROR'),
    )
  }

  db.prepare(
    `UPDATE jobs SET
      title = ?, department = ?, status = ?, employment_type = ?, location = ?, salary_min = ?, salary_max = ?,
      about_role = ?, responsibilities = ?, company_info = ?, team_info = ?, benefits = ?,
      criteria_template_id = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
  ).run(
    fields.title.trim(),
    fields.department || null,
    VALID_STATUSES.has(fields.status) ? fields.status : existing.status || 'open',
    fields.employment_type || null,
    fields.location || null,
    fields.salary_min ?? null,
    fields.salary_max ?? null,
    fields.about_role || null,
    fields.responsibilities || null,
    fields.company_info || null,
    fields.team_info || null,
    fields.benefits || null,
    fields.criteria_template_id,
    req.params.id,
  )

  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(req.params.id)
  res.json(serializeJob(row))
}

export function deleteJob(req, res, next) {
  const existing = db.prepare('SELECT id FROM jobs WHERE id = ?').get(req.params.id)
  if (!existing) return next(new ApiError(404, 'Job not found', 'NOT_FOUND'))

  db.prepare('DELETE FROM candidate_evaluations WHERE job_id = ?').run(req.params.id)
  db.prepare('DELETE FROM jobs WHERE id = ?').run(req.params.id)
  res.status(204).send()
}
