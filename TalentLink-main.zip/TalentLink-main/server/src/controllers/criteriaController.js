import db from '../services/db.js'
import { toJson, fromJson } from '../services/jsonColumn.js'
import { ApiError } from '../middleware/errorHandler.js'

const CATEGORY_KEYS = ['technical_skills', 'experience', 'education', 'portfolio', 'competencies']

function serializeCriteria(row) {
  if (!row) return null
  return {
    ...row,
    required_skills: fromJson(row.required_skills),
    preferred_skills: fromJson(row.preferred_skills),
    competencies: fromJson(row.competencies),
    certifications: fromJson(row.certifications),
    education_requirements: fromJson(row.education_requirements),
    portfolio_requirements: fromJson(row.portfolio_requirements),
    evaluation_rules: fromJson(row.evaluation_rules, {}),
  }
}

function validateEvaluationRules(rules) {
  if (!rules || typeof rules !== 'object') {
    return 'evaluation_rules is required'
  }
  let sum = 0
  for (const key of CATEGORY_KEYS) {
    const rule = rules[key]
    if (!rule || typeof rule !== 'object') {
      return `evaluation_rules.${key} is required`
    }
    if (!rule.method || !String(rule.method).trim()) {
      return `evaluation_rules.${key} must explain how it is evaluated`
    }
    sum += Number(rule.weight) || 0
  }
  if (sum !== 100) {
    return `Evaluation weights must add up to 100 (currently ${sum})`
  }
  return null
}

export function listCriteria(req, res) {
  const { department, role } = req.query
  let sql = 'SELECT * FROM criteria_templates WHERE 1=1'
  const params = []

  if (department) {
    sql += ' AND department LIKE ?'
    params.push(`%${department}%`)
  }
  if (role) {
    sql += ' AND role_title LIKE ?'
    params.push(`%${role}%`)
  }
  sql += ' ORDER BY department, role_title'

  const rows = db.prepare(sql).all(...params)
  res.json(rows.map(serializeCriteria))
}

export function getCriteria(req, res, next) {
  const row = db.prepare('SELECT * FROM criteria_templates WHERE id = ?').get(req.params.id)
  if (!row) return next(new ApiError(404, 'Criteria template not found', 'NOT_FOUND'))
  res.json(serializeCriteria(row))
}

function readCriteriaFields(body) {
  const {
    department,
    role_title,
    description,
    education_requirements,
    minimum_experience_years,
    certifications,
    min_age,
    max_age,
    required_skills,
    preferred_skills,
    competencies,
    portfolio_requirements,
    evaluation_rules,
  } = body || {}
  return {
    department,
    role_title,
    description,
    education_requirements,
    minimum_experience_years,
    certifications,
    min_age,
    max_age,
    required_skills,
    preferred_skills,
    competencies,
    portfolio_requirements,
    evaluation_rules,
  }
}

export function createCriteria(req, res, next) {
  const fields = readCriteriaFields(req.body)

  if (!fields.department?.trim()) return next(new ApiError(400, 'Department is required', 'VALIDATION_ERROR'))
  if (!fields.role_title?.trim()) return next(new ApiError(400, 'Role title is required', 'VALIDATION_ERROR'))
  if (!Array.isArray(fields.required_skills) || fields.required_skills.length === 0) {
    return next(new ApiError(400, 'At least one required skill is needed', 'VALIDATION_ERROR'))
  }

  const rulesError = validateEvaluationRules(fields.evaluation_rules)
  if (rulesError) return next(new ApiError(400, rulesError, 'VALIDATION_ERROR'))

  const result = db
    .prepare(
      `INSERT INTO criteria_templates
        (department, role_title, description, education_requirements, minimum_experience_years,
         certifications, min_age, max_age, required_skills, preferred_skills, competencies,
         portfolio_requirements, evaluation_rules, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      fields.department.trim(),
      fields.role_title.trim(),
      fields.description || null,
      toJson(fields.education_requirements || []),
      fields.minimum_experience_years ?? null,
      toJson(fields.certifications || []),
      fields.min_age ?? null,
      fields.max_age ?? null,
      toJson(fields.required_skills || []),
      toJson(fields.preferred_skills || []),
      toJson(fields.competencies || []),
      toJson(fields.portfolio_requirements || []),
      toJson(fields.evaluation_rules),
      req.user.id,
    )

  const row = db.prepare('SELECT * FROM criteria_templates WHERE id = ?').get(result.lastInsertRowid)
  res.status(201).json(serializeCriteria(row))
}

export function updateCriteria(req, res, next) {
  const existing = db.prepare('SELECT id FROM criteria_templates WHERE id = ?').get(req.params.id)
  if (!existing) return next(new ApiError(404, 'Criteria template not found', 'NOT_FOUND'))

  const fields = readCriteriaFields(req.body)

  if (!fields.department?.trim()) return next(new ApiError(400, 'Department is required', 'VALIDATION_ERROR'))
  if (!fields.role_title?.trim()) return next(new ApiError(400, 'Role title is required', 'VALIDATION_ERROR'))
  if (!Array.isArray(fields.required_skills) || fields.required_skills.length === 0) {
    return next(new ApiError(400, 'At least one required skill is needed', 'VALIDATION_ERROR'))
  }

  const rulesError = validateEvaluationRules(fields.evaluation_rules)
  if (rulesError) return next(new ApiError(400, rulesError, 'VALIDATION_ERROR'))

  db.prepare(
    `UPDATE criteria_templates SET
      department = ?, role_title = ?, description = ?, education_requirements = ?, minimum_experience_years = ?,
      certifications = ?, min_age = ?, max_age = ?, required_skills = ?, preferred_skills = ?, competencies = ?,
      portfolio_requirements = ?, evaluation_rules = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
  ).run(
    fields.department.trim(),
    fields.role_title.trim(),
    fields.description || null,
    toJson(fields.education_requirements || []),
    fields.minimum_experience_years ?? null,
    toJson(fields.certifications || []),
    fields.min_age ?? null,
    fields.max_age ?? null,
    toJson(fields.required_skills || []),
    toJson(fields.preferred_skills || []),
    toJson(fields.competencies || []),
    toJson(fields.portfolio_requirements || []),
    toJson(fields.evaluation_rules),
    req.params.id,
  )

  const row = db.prepare('SELECT * FROM criteria_templates WHERE id = ?').get(req.params.id)
  res.json(serializeCriteria(row))
}

export function deleteCriteria(req, res, next) {
  const existing = db.prepare('SELECT id FROM criteria_templates WHERE id = ?').get(req.params.id)
  if (!existing) return next(new ApiError(404, 'Criteria template not found', 'NOT_FOUND'))

  // Detach rather than block/cascade - jobs and past evaluations keep working,
  // matching how deleteJob/deleteAccount handle their own foreign references.
  db.prepare('UPDATE jobs SET criteria_template_id = NULL WHERE criteria_template_id = ?').run(req.params.id)
  db.prepare('UPDATE candidate_evaluations SET criteria_template_id = NULL WHERE criteria_template_id = ?').run(
    req.params.id,
  )
  db.prepare('DELETE FROM criteria_templates WHERE id = ?').run(req.params.id)
  res.status(204).send()
}
