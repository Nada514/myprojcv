import db from '../services/db.js'
import { toJson, fromJson } from '../services/jsonColumn.js'
import { matchCandidateToJob } from '../services/ai/matchCandidate.js'
import { checkHardRequirements } from '../services/hardRequirements.js'
import { ApiError } from '../middleware/errorHandler.js'

const CATEGORY_LABELS = {
  technical_skills: 'Technical Skills',
  experience: 'Experience',
  education: 'Education',
  portfolio: 'Projects / Portfolio',
  competencies: 'Professional Competencies',
}
const CATEGORY_KEYS = Object.keys(CATEGORY_LABELS)

function serializeJobRow(row) {
  return {
    title: row.title,
    department: row.department,
    employment_type: row.employment_type,
    location: row.location,
    about_role: row.about_role,
    responsibilities: row.responsibilities,
    company_info: row.company_info,
    team_info: row.team_info,
    benefits: row.benefits,
  }
}

function serializeCandidateRow(row) {
  return {
    name: row.name,
    age: row.age,
    education: fromJson(row.education),
    skills: fromJson(row.skills),
    programming_languages: fromJson(row.programming_languages),
    experience: fromJson(row.experience),
    total_experience_years: row.total_experience_years,
    certifications: fromJson(row.certifications),
    projects: fromJson(row.projects),
  }
}

function serializeEvaluation(row) {
  if (!row) return null
  return {
    ...row,
    department_breakdown: fromJson(row.department_breakdown),
    company_matches: fromJson(row.company_matches),
    company_gaps: fromJson(row.company_gaps),
    missing_requirements: fromJson(row.missing_requirements),
  }
}

function serializeCriteriaRow(row) {
  if (!row) return null
  return {
    department: row.department,
    role_title: row.role_title,
    description: row.description,
    education_requirements: fromJson(row.education_requirements),
    minimum_experience_years: row.minimum_experience_years,
    certifications: fromJson(row.certifications),
    min_age: row.min_age,
    max_age: row.max_age,
    required_skills: fromJson(row.required_skills),
    preferred_skills: fromJson(row.preferred_skills),
    competencies: fromJson(row.competencies),
    portfolio_requirements: fromJson(row.portfolio_requirements),
    evaluation_rules: fromJson(row.evaluation_rules, {}),
  }
}

// Builds the per-category weighted breakdown deterministically from the
// template's own weights, rather than trusting the model to do the
// arithmetic - the weights the department set are what actually drive the
// score, and the result is reproducible/auditable.
function buildDepartmentResult(aiResult, evaluationRules) {
  const breakdown = CATEGORY_KEYS.map((key) => {
    const category = aiResult[key] || { score: 0, evidence_found: [], missing: [], reason: '' }
    const weight = Number(evaluationRules?.[key]?.weight) || 0
    const score = Number(category.score) || 0
    const contribution = Math.round((score * weight) / 100 * 10) / 10
    return {
      key,
      label: CATEGORY_LABELS[key],
      weight,
      score: Math.round(score),
      contribution,
      evidence_found: category.evidence_found || [],
      missing: category.missing || [],
      reason: category.reason || '',
    }
  })
  const department_score = Math.round(breakdown.reduce((total, c) => total + c.contribution, 0))
  return { breakdown, department_score }
}

async function evaluateOne(jobRow, candidateRow) {
  if (!jobRow.criteria_template_id) {
    throw new Error(
      `"${jobRow.title}" has no criteria template attached - edit the job and select a department standard before running AI matching.`,
    )
  }

  const criteriaRow = db.prepare('SELECT * FROM criteria_templates WHERE id = ?').get(jobRow.criteria_template_id)
  if (!criteriaRow) {
    throw new Error(`"${jobRow.title}"'s criteria template no longer exists - select a new one before running AI matching.`)
  }

  const jobPosting = serializeJobRow(jobRow)
  const candidateProfile = serializeCandidateRow(candidateRow)
  const criteriaTemplate = serializeCriteriaRow(criteriaRow)

  const aiResult = await matchCandidateToJob(candidateProfile, jobPosting, criteriaTemplate)
  const { breakdown, department_score } = buildDepartmentResult(aiResult, criteriaTemplate.evaluation_rules)
  const company_score = Math.round(Number(aiResult.company_score) || 0)
  const overall_score = Math.round((department_score + company_score) / 2)
  const missingRequirements = checkHardRequirements(criteriaTemplate, candidateRow)

  db.prepare(
    `INSERT INTO candidate_evaluations
      (candidate_id, job_id, criteria_template_id, overall_score, overall_explanation,
       department_score, department_breakdown, company_score, company_explanation,
       company_matches, company_gaps, missing_requirements, evaluated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
     ON CONFLICT(candidate_id, job_id) DO UPDATE SET
       criteria_template_id = excluded.criteria_template_id,
       overall_score = excluded.overall_score,
       overall_explanation = excluded.overall_explanation,
       department_score = excluded.department_score,
       department_breakdown = excluded.department_breakdown,
       company_score = excluded.company_score,
       company_explanation = excluded.company_explanation,
       company_matches = excluded.company_matches,
       company_gaps = excluded.company_gaps,
       missing_requirements = excluded.missing_requirements,
       evaluated_at = CURRENT_TIMESTAMP`,
  ).run(
    candidateRow.id,
    jobRow.id,
    jobRow.criteria_template_id,
    overall_score,
    aiResult.overall_explanation,
    department_score,
    toJson(breakdown),
    company_score,
    aiResult.company_explanation,
    toJson(aiResult.company_matches || []),
    toJson(aiResult.company_gaps || []),
    toJson(missingRequirements),
  )
}

export async function runMatch(req, res, next) {
  const job = db.prepare('SELECT * FROM jobs WHERE id = ?').get(req.params.jobId)
  if (!job) return next(new ApiError(404, 'Job not found', 'NOT_FOUND'))

  const { candidateIds } = req.body || {}
  const candidates = candidateIds?.length
    ? candidateIds.map((id) => db.prepare('SELECT * FROM candidates WHERE id = ?').get(id)).filter(Boolean)
    : db.prepare('SELECT * FROM candidates').all()

  if (candidates.length === 0) {
    return next(new ApiError(400, 'No candidates available to match', 'VALIDATION_ERROR'))
  }

  const errors = []
  for (const candidate of candidates) {
    try {
      await evaluateOne(job, candidate)
    } catch (err) {
      errors.push({ candidateId: candidate.id, message: err.message })
    }
  }

  const evaluations = db
    .prepare(
      `SELECT ce.*, c.name as candidate_name FROM candidate_evaluations ce
       JOIN candidates c ON c.id = ce.candidate_id
       WHERE ce.job_id = ? ORDER BY ce.overall_score DESC`,
    )
    .all(job.id)
    .map(serializeEvaluation)

  res.json({ evaluations, errors })
}

export function listEvaluationsForJob(req, res, next) {
  const job = db.prepare('SELECT id FROM jobs WHERE id = ?').get(req.params.jobId)
  if (!job) return next(new ApiError(404, 'Job not found', 'NOT_FOUND'))

  const { sort } = req.query
  const orderBy = sort === 'score' ? 'ce.overall_score DESC' : 'ce.evaluated_at DESC'

  const rows = db
    .prepare(
      `SELECT ce.*, c.name as candidate_name, c.email as candidate_email
       FROM candidate_evaluations ce
       JOIN candidates c ON c.id = ce.candidate_id
       WHERE ce.job_id = ? ORDER BY ${orderBy}`,
    )
    .all(req.params.jobId)

  res.json(rows.map(serializeEvaluation))
}

export function getEvaluation(req, res, next) {
  const row = db
    .prepare('SELECT * FROM candidate_evaluations WHERE job_id = ? AND candidate_id = ?')
    .get(req.params.jobId, req.params.candidateId)
  if (!row) return next(new ApiError(404, 'Evaluation not found', 'NOT_FOUND'))
  res.json(serializeEvaluation(row))
}
