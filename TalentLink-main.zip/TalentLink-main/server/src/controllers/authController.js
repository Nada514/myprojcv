import path from 'node:path'
import fs from 'node:fs'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import db from '../services/db.js'
import { toJson, fromJson } from '../services/jsonColumn.js'
import { ApiError } from '../middleware/errorHandler.js'
import { COOKIE_NAME } from '../middleware/auth.js'
import { avatarsDir } from '../middleware/uploadAvatar.js'

const isProduction = process.env.NODE_ENV === 'production'
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const MIN_PASSWORD_LENGTH = 8
const BIO_MAX_LENGTH = 1000
const SESSION_MAX_AGE = 7 * 24 * 60 * 60 * 1000 // 7 days
const REMEMBER_ME_MAX_AGE = 30 * 24 * 60 * 60 * 1000 // 30 days

const DEFAULT_PREFERENCES = {
  emailNotifications: true,
  aiEvaluationNotifications: true,
  defaultSortByScore: true,
}

// Kept minimal and stable - this is what gets signed into the JWT cookie on
// every request. Profile edits (name/email/bio/etc) are always read fresh
// from the database instead of trusted from stale token claims.
function sessionClaims(user) {
  return { id: user.id, name: user.name, email: user.email }
}

// Full profile shape returned by the API - never includes password_hash.
function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone || null,
    job_title: user.job_title || null,
    department: user.department || null,
    bio: user.bio || null,
    profile_image: user.profile_image || null,
    role: user.role || 'recruiter',
    preferences: { ...DEFAULT_PREFERENCES, ...fromJson(user.preferences, {}) },
    created_at: user.created_at,
    last_login_at: user.last_login_at || null,
  }
}

function setAuthCookie(res, user, rememberMe) {
  const maxAge = rememberMe ? REMEMBER_ME_MAX_AGE : SESSION_MAX_AGE
  const token = jwt.sign(sessionClaims(user), process.env.JWT_SECRET, {
    expiresIn: rememberMe ? '30d' : process.env.JWT_EXPIRES_IN || '7d',
  })
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: isProduction,
    sameSite: 'lax',
    maxAge,
  })
}

function removeAvatarFile(profileImage) {
  if (!profileImage) return
  const filePath = path.join(avatarsDir, path.basename(profileImage))
  fs.unlink(filePath, () => {}) // best-effort cleanup - a missing file is not an error here
}

export function register(req, res, next) {
  const { name, email, password, confirmPassword } = req.body || {}

  if (!name?.trim() || !email?.trim() || !password || !confirmPassword) {
    return next(new ApiError(400, 'All fields are required', 'VALIDATION_ERROR'))
  }
  if (!EMAIL_REGEX.test(email.trim())) {
    return next(new ApiError(400, 'Please enter a valid email address', 'VALIDATION_ERROR'))
  }
  if (password.length < MIN_PASSWORD_LENGTH) {
    return next(
      new ApiError(400, `Password must be at least ${MIN_PASSWORD_LENGTH} characters`, 'VALIDATION_ERROR'),
    )
  }
  if (password !== confirmPassword) {
    return next(new ApiError(400, 'Passwords do not match', 'VALIDATION_ERROR'))
  }

  const normalizedEmail = email.trim().toLowerCase()
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail)
  if (existing) {
    return next(new ApiError(409, 'An account with this email already exists', 'DUPLICATE_ACCOUNT'))
  }

  const passwordHash = bcrypt.hashSync(password, 10)
  const result = db
    .prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)')
    .run(name.trim(), normalizedEmail, passwordHash)

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid)
  // Registration does not start a session - the user logs in explicitly afterward.
  res.status(201).json(publicUser(user))
}

export function login(req, res, next) {
  const { email, password, rememberMe } = req.body || {}
  if (!email?.trim() || !password) {
    return next(new ApiError(400, 'Email and password are required', 'VALIDATION_ERROR'))
  }

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.trim().toLowerCase())
  if (!user) {
    return next(new ApiError(404, 'No account found with this email', 'ACCOUNT_NOT_FOUND'))
  }
  if (!bcrypt.compareSync(password, user.password_hash)) {
    return next(new ApiError(401, 'Incorrect password', 'INVALID_CREDENTIALS'))
  }

  setAuthCookie(res, user, Boolean(rememberMe))
  db.prepare('UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?').run(user.id)
  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id)
  res.json(publicUser(updated))
}

export function logout(req, res) {
  res.clearCookie(COOKIE_NAME)
  res.status(204).send()
}

export function me(req, res, next) {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  if (!user) return next(new ApiError(401, 'Not authenticated', 'UNAUTHENTICATED'))
  res.json(publicUser(user))
}

export const getProfile = me

export function updateProfile(req, res, next) {
  const { name, email, phone, job_title, department, bio } = req.body || {}

  if (!name?.trim()) return next(new ApiError(400, 'Full name is required', 'VALIDATION_ERROR'))
  if (!email?.trim()) return next(new ApiError(400, 'Email is required', 'VALIDATION_ERROR'))
  if (!EMAIL_REGEX.test(email.trim())) {
    return next(new ApiError(400, 'Please enter a valid email address', 'VALIDATION_ERROR'))
  }
  if (bio && bio.length > BIO_MAX_LENGTH) {
    return next(new ApiError(400, `Bio must be ${BIO_MAX_LENGTH} characters or fewer`, 'VALIDATION_ERROR'))
  }

  const normalizedEmail = email.trim().toLowerCase()
  const duplicate = db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(normalizedEmail, req.user.id)
  if (duplicate) {
    return next(new ApiError(409, 'An account with this email already exists', 'DUPLICATE_ACCOUNT'))
  }

  db.prepare(
    `UPDATE users SET name = ?, email = ?, phone = ?, job_title = ?, department = ?, bio = ? WHERE id = ?`,
  ).run(
    name.trim(),
    normalizedEmail,
    phone?.trim() || null,
    job_title?.trim() || null,
    department?.trim() || null,
    bio?.trim() || null,
    req.user.id,
  )

  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  res.json(publicUser(updated))
}

export function updatePreferences(req, res, next) {
  const incoming = req.body?.preferences
  if (!incoming || typeof incoming !== 'object') {
    return next(new ApiError(400, 'preferences object is required', 'VALIDATION_ERROR'))
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  const current = fromJson(user.preferences, {})
  const merged = { ...DEFAULT_PREFERENCES, ...current, ...incoming }

  db.prepare('UPDATE users SET preferences = ? WHERE id = ?').run(toJson(merged), req.user.id)
  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  res.json(publicUser(updated))
}

export function changePassword(req, res, next) {
  const { currentPassword, newPassword, confirmPassword } = req.body || {}

  if (!currentPassword || !newPassword || !confirmPassword) {
    return next(new ApiError(400, 'All password fields are required', 'VALIDATION_ERROR'))
  }
  if (newPassword.length < MIN_PASSWORD_LENGTH) {
    return next(
      new ApiError(400, `New password must be at least ${MIN_PASSWORD_LENGTH} characters`, 'VALIDATION_ERROR'),
    )
  }
  if (newPassword !== confirmPassword) {
    return next(new ApiError(400, 'New passwords do not match', 'VALIDATION_ERROR'))
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  if (!user || !bcrypt.compareSync(currentPassword, user.password_hash)) {
    return next(new ApiError(401, 'Current password is incorrect', 'INVALID_CREDENTIALS'))
  }
  if (bcrypt.compareSync(newPassword, user.password_hash)) {
    return next(
      new ApiError(400, 'New password must be different from your current password', 'VALIDATION_ERROR'),
    )
  }

  const passwordHash = bcrypt.hashSync(newPassword, 10)
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(passwordHash, req.user.id)
  res.status(204).send()
}

export function uploadAvatar(req, res, next) {
  if (!req.file) return next(new ApiError(400, 'An image file is required', 'VALIDATION_ERROR'))

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  removeAvatarFile(user.profile_image)

  const publicPath = `/avatars/${req.file.filename}`
  db.prepare('UPDATE users SET profile_image = ? WHERE id = ?').run(publicPath, req.user.id)
  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  res.json(publicUser(updated))
}

export function deleteAccount(req, res, next) {
  const { password } = req.body || {}
  if (!password) {
    return next(new ApiError(400, 'Enter your password to confirm account deletion', 'VALIDATION_ERROR'))
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return next(new ApiError(401, 'Incorrect password', 'INVALID_CREDENTIALS'))
  }

  // Jobs aren't exclusively "owned" by their creator in this shared-workspace app -
  // detach rather than cascade-delete so other recruiters' work survives.
  db.prepare('UPDATE jobs SET created_by = NULL WHERE created_by = ?').run(req.user.id)
  removeAvatarFile(user.profile_image)
  db.prepare('DELETE FROM users WHERE id = ?').run(req.user.id)

  res.clearCookie(COOKIE_NAME)
  res.status(204).send()
}
