import db from '../services/db.js'
import { fromJson } from '../services/jsonColumn.js'
import { ApiError } from '../middleware/errorHandler.js'

function serializeCandidate(row) {
  if (!row) return null
  return {
    ...row,
    education: fromJson(row.education),
    skills: fromJson(row.skills),
    programming_languages: fromJson(row.programming_languages),
    experience: fromJson(row.experience),
    certifications: fromJson(row.certifications),
    projects: fromJson(row.projects),
    missing_fields: fromJson(row.missing_fields),
  }
}

function withResume(candidate) {
  if (!candidate) return null
  const resume = db
    .prepare('SELECT id, original_filename, file_type, uploaded_at FROM resumes WHERE id = ?')
    .get(candidate.resume_id)
  return { ...candidate, resume }
}

export function listCandidates(req, res) {
  const { age_min, age_max, experience_min, education, skill, language, certification, score_min, sort } =
    req.query

  let rows = db.prepare('SELECT * FROM candidates ORDER BY extracted_at DESC').all()
  let candidates = rows.map(serializeCandidate)

  if (age_min) candidates = candidates.filter((c) => c.age != null && c.age >= Number(age_min))
  if (age_max) candidates = candidates.filter((c) => c.age != null && c.age <= Number(age_max))
  if (experience_min) {
    candidates = candidates.filter(
      (c) => c.total_experience_years != null && c.total_experience_years >= Number(experience_min),
    )
  }
  if (education) {
    const needle = education.toLowerCase()
    candidates = candidates.filter((c) =>
      c.education.some((e) => `${e.degree} ${e.university}`.toLowerCase().includes(needle)),
    )
  }
  if (skill) {
    const needle = skill.toLowerCase()
    candidates = candidates.filter((c) => c.skills.some((s) => s.toLowerCase().includes(needle)))
  }
  if (language) {
    const needle = language.toLowerCase()
    candidates = candidates.filter((c) =>
      c.programming_languages.some((l) => l.toLowerCase().includes(needle)),
    )
  }
  if (certification) {
    const needle = certification.toLowerCase()
    candidates = candidates.filter((c) =>
      c.certifications.some((cert) => cert.toLowerCase().includes(needle)),
    )
  }

  // Attach best evaluation score across jobs so the list can be filtered/sorted by match quality.
  let withScores = candidates.map((c) => {
    const best = db
      .prepare(
        'SELECT MAX(overall_score) as best_score FROM candidate_evaluations WHERE candidate_id = ?',
      )
      .get(c.id)
    return { ...c, best_score: best?.best_score ?? null }
  })

  if (score_min) {
    withScores = withScores.filter((c) => c.best_score != null && c.best_score >= Number(score_min))
  }

  if (sort === 'score') {
    withScores.sort((a, b) => (b.best_score ?? -1) - (a.best_score ?? -1))
  }

  res.json(withScores)
}

export function getCandidate(req, res, next) {
  const row = db.prepare('SELECT * FROM candidates WHERE id = ?').get(req.params.id)
  if (!row) return next(new ApiError(404, 'Candidate not found', 'NOT_FOUND'))

  const evaluations = db
    .prepare(
      `SELECT ce.*, j.title as job_title FROM candidate_evaluations ce
       JOIN jobs j ON j.id = ce.job_id
       WHERE ce.candidate_id = ? ORDER BY ce.evaluated_at DESC`,
    )
    .all(req.params.id)
    .map((e) => ({
      ...e,
      department_breakdown: fromJson(e.department_breakdown),
      company_matches: fromJson(e.company_matches),
      company_gaps: fromJson(e.company_gaps),
      missing_requirements: fromJson(e.missing_requirements),
    }))

  res.json({ ...withResume(serializeCandidate(row)), evaluations })
}

export function deleteCandidate(req, res, next) {
  const existing = db.prepare('SELECT id FROM candidates WHERE id = ?').get(req.params.id)
  if (!existing) return next(new ApiError(404, 'Candidate not found', 'NOT_FOUND'))

  db.prepare('DELETE FROM candidate_evaluations WHERE candidate_id = ?').run(req.params.id)
  db.prepare('DELETE FROM candidates WHERE id = ?').run(req.params.id)
  res.status(204).send()
}
